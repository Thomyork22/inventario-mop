import { Routes, Route, Navigate } from "react-router-dom";

import AppLayout from "./layouts/AppLayout.jsx";

// Pages
import LoginPage from "./pages/LoginPage.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import InventarioPage from "./pages/InventarioPage.jsx";
import MantencionesPage from "./pages/MantencionesPage.jsx";
import FuncionariosPage from "./pages/FuncionariosPage.jsx";
import ReportesPage from "./pages/ReportesPage.jsx";
import ConfiguracionPage from "./pages/ConfiguracionPage.jsx";

// --- Auth helpers (simple, después lo mejoramos con refresh automático) ---
function hasAccessToken() {
  return Boolean(localStorage.getItem("access_token"));
}

function RequireAuth({ children }) {
  if (!hasAccessToken()) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      {/* Landing */}
      <Route path="/" element={<Navigate to="/dashboard" replace />} />

      {/* Public */}
      <Route path="/login" element={<LoginPage />} />

      {/* Protected (todo lo que tiene Sidebar/Topbar) */}
      <Route
        element={
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        }
      >
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/inventario" element={<InventarioPage />} />
        <Route path="/mantenciones" element={<MantencionesPage />} />
        <Route path="/funcionarios" element={<FuncionariosPage />} />
        <Route path="/reportes" element={<ReportesPage />} />
        <Route path="/configuracion" element={<ConfiguracionPage />} />
      </Route>

      {/* 404 */}
      <Route path="*" element={<div style={{ padding: 24 }}>404</div>} />
    </Routes>
  );
}
