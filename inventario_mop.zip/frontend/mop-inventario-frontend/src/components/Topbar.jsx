import { useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";
import { useAuth } from "../auth/AuthContext.jsx";

export default function Topbar() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  function handleLogout() {
    logout();
    navigate("/login", { replace: true });
  }

  const displayName = user?.username || "Usuario";
  const role = user?.is_superuser
    ? "Administrador"
    : user?.groups?.[0] || "Usuario";

  return (
    <header style={styles.header}>
      <div />

      <div style={styles.userBox}>
        <div style={styles.avatar} />
        <div style={styles.userText}>
          <div style={styles.userName}>{displayName}</div>
          <div style={styles.userRole}>{role}</div>
        </div>

        <button style={styles.logoutBtn} title="Salir" onClick={handleLogout}>
          <LogOut size={18} />
        </button>
      </div>
    </header>
  );
}

const styles = {
  header: {
    height: 60,
    background: "#fff",
    borderBottom: "1px solid #e9e9ee",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 18px",
  },
  userBox: {
    display: "flex",
    alignItems: "center",
    gap: 10,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 999,
    background: "#d9d9e3",
  },
  userText: {
    display: "flex",
    flexDirection: "column",
    lineHeight: "14px",
  },
  userName: {
    fontWeight: 700,
    fontSize: 12,
  },
  userRole: {
    fontSize: 11,
    color: "#666",
  },
  logoutBtn: {
    border: "1px solid #e9e9ee",
    background: "#fff",
    borderRadius: 10,
    padding: "8px 10px",
    cursor: "pointer",
  },
};
