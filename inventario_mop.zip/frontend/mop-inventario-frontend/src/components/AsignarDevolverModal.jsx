import { useEffect, useMemo, useState } from "react";
import { api } from "../api/api";

function todayISO() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export default function AsignarDevolverModal({
  open,
  onClose,
  equipo,
  estadosCatalogo = [],
  onDone, // callback para recargar
}) {
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  // funcionarios
  const [q, setQ] = useState("");
  const [funcionarios, setFuncionarios] = useState([]);
  const [selectedFuncionarioId, setSelectedFuncionarioId] = useState("");

  // asignación activa (si existe)
  const [activeAsignacion, setActiveAsignacion] = useState(null);

  // form
  const [motivo, setMotivo] = useState("");
  const [fechaAsignacion, setFechaAsignacion] = useState(todayISO());
  const [fechaDevolucion, setFechaDevolucion] = useState(todayISO());

  const isOcupado = useMemo(() => {
    const txt = (equipo?.estado?.descripcion || "").toLowerCase();
    return txt.includes("ocup");
  }, [equipo]);

  const estadoLibreId = useMemo(() => {
    const x = estadosCatalogo.find((e) => (e.descripcion || "").toLowerCase().includes("libre"));
    return x?.codigo_estado || null;
  }, [estadosCatalogo]);

  const estadoOcupadoId = useMemo(() => {
    const x = estadosCatalogo.find((e) => (e.descripcion || "").toLowerCase().includes("ocup"));
    return x?.codigo_estado || null;
  }, [estadosCatalogo]);

  // ESC
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose?.();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  // al abrir: cargar asignación activa y funcionarios iniciales
  useEffect(() => {
    if (!open || !equipo?.id_equipo) return;

    setErr("");
    setQ("");
    setFuncionarios([]);
    setSelectedFuncionarioId("");
    setMotivo("");
    setFechaAsignacion(todayISO());
    setFechaDevolucion(todayISO());

    (async () => {
      try {
        // 1) buscar asignaciones del equipo y quedarnos con la activa (si existe)
        const asigRes = await api.get("/asignaciones/", {
          params: { id_equipo: equipo.id_equipo, ordering: "-id_asignacion" },
        });
        const list = asigRes.data?.results ?? asigRes.data ?? [];
        const activa = list.find((a) => a?.activo === true && !a?.fecha_devolucion) || null;
        setActiveAsignacion(activa);

        // 2) traer algunos funcionarios (o vacio)
        const fRes = await api.get("/funcionarios/", { params: { search: "" } });
        setFuncionarios(fRes.data?.results ?? fRes.data ?? []);
      } catch (e) {
        console.error(e);
        setErr(e?.response?.data?.detail || "Error cargando datos para asignación.");
      }
    })();
  }, [open, equipo]);

  // buscar funcionarios con debounce simple
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(async () => {
      try {
        const res = await api.get("/funcionarios/", { params: { search: q } });
        setFuncionarios(res.data?.results ?? res.data ?? []);
      } catch {
        // silencioso
      }
    }, 300);
    return () => clearTimeout(t);
  }, [q, open]);

  if (!open) return null;

  async function patchEquipoEstado(codigo_estado_id) {
    if (!codigo_estado_id) return; // si no existe en catálogo, no rompemos
    await api.patch(`/equipos/${equipo.id_equipo}/`, { codigo_estado_id });
  }

  async function handleAsignar() {
    setLoading(true);
    setErr("");
    try {
      if (!selectedFuncionarioId) {
        throw new Error("Selecciona un funcionario.");
      }

      // 1) crear asignación
      await api.post("/asignaciones/", {
        id_equipo_id: equipo.id_equipo,
        id_funcionario_id: Number(selectedFuncionarioId),
        fecha_asignacion: fechaAsignacion,
        motivo_asignacion: motivo || null,
        estado_asignacion: "Activa",
        activo: true,
      });



      onDone?.();
      onClose?.();
    } catch (e) {
      const msg =
        e?.response?.data?.detail ||
        (typeof e?.response?.data === "object" ? JSON.stringify(e.response.data) : null) ||
        e?.message ||
        "No se pudo asignar.";
      setErr(msg);
    } finally {
      setLoading(false);
    }
  }

  async function handleDevolver() {
    setLoading(true);
    setErr("");
    try {
      if (!activeAsignacion?.id_asignacion) {
        throw new Error("No se encontró una asignación activa para devolver.");
      }

      // 1) cerrar asignación (devolución)
      await api.patch(`/asignaciones/${activeAsignacion.id_asignacion}/`, {
        fecha_devolucion: fechaDevolucion,
        estado_asignacion: "Cerrada",
        activo: false,
      });



      onDone?.();
      onClose?.();
    } catch (e) {
      const msg =
        e?.response?.data?.detail ||
        (typeof e?.response?.data === "object" ? JSON.stringify(e.response.data) : null) ||
        e?.message ||
        "No se pudo devolver.";
      setErr(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.backdrop} onMouseDown={onClose}>
      <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
        <div style={styles.header}>
          <div>
            <div style={styles.title}>Asignar / Devolver</div>
            <div style={styles.sub}>
              {equipo?.numero_inventario || "—"} · {equipo?.modelo || "—"}
            </div>
          </div>
          <button style={styles.closeBtn} onClick={onClose} title="Cerrar">
            ✕
          </button>
        </div>

        <div style={styles.body}>
          {err ? <div style={styles.error}>{err}</div> : null}

          {!isOcupado ? (
            <>
              <div style={styles.blockTitle}>Asignar a funcionario</div>

              <div style={styles.grid2}>
                <div style={styles.field}>
                  <div style={styles.label}>Buscar funcionario</div>
                  <input
                    style={styles.input}
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="Nombre, RUT o correo…"
                  />
                </div>

                <div style={styles.field}>
                  <div style={styles.label}>Funcionario</div>
                  <select
                    style={styles.select}
                    value={selectedFuncionarioId}
                    onChange={(e) => setSelectedFuncionarioId(e.target.value)}
                  >
                    <option value="">Selecciona…</option>
                    {funcionarios.map((f) => (
                      <option key={f.id_funcionario} value={f.id_funcionario}>
                        {f.nombre_completo} ({f.rut})
                      </option>
                    ))}
                  </select>
                </div>

                <div style={styles.field}>
                  <div style={styles.label}>Fecha asignación</div>
                  <input
                    style={styles.input}
                    type="date"
                    value={fechaAsignacion}
                    onChange={(e) => setFechaAsignacion(e.target.value)}
                  />
                </div>

                <div style={styles.field}>
                  <div style={styles.label}>Motivo</div>
                  <input
                    style={styles.input}
                    value={motivo}
                    onChange={(e) => setMotivo(e.target.value)}
                    placeholder="Ej: Entrega por reemplazo, nuevo funcionario…"
                  />
                </div>
              </div>
            </>
          ) : (
            <>
              <div style={styles.blockTitle}>Devolver equipo</div>

              <div style={styles.infoCard}>
                <div style={{ fontWeight: 900, color: "#0b1b3a" }}>
                  Asignación activa
                </div>
                <div style={{ marginTop: 6, color: "#475467", fontSize: 13 }}>
                  {activeAsignacion?.funcionario
                    ? `${activeAsignacion.funcionario.nombre_completo} (${activeAsignacion.funcionario.rut})`
                    : "No se pudo cargar el funcionario."}
                </div>
              </div>

              <div style={styles.grid2}>
                <div style={styles.field}>
                  <div style={styles.label}>Fecha devolución</div>
                  <input
                    style={styles.input}
                    type="date"
                    value={fechaDevolucion}
                    onChange={(e) => setFechaDevolucion(e.target.value)}
                  />
                </div>
                <div />
              </div>
            </>
          )}
        </div>

        <div style={styles.footer}>
          <button style={styles.secondaryBtn} onClick={onClose} disabled={loading}>
            Cancelar
          </button>

          {!isOcupado ? (
            <button style={styles.primaryBtn} onClick={handleAsignar} disabled={loading}>
              {loading ? "Asignando…" : "Asignar"}
            </button>
          ) : (
            <button style={styles.primaryBtn} onClick={handleDevolver} disabled={loading}>
              {loading ? "Devolviendo…" : "Devolver"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

const styles = {
  backdrop: {
    position: "fixed",
    inset: 0,
    background: "rgba(15, 23, 42, 0.45)",
    display: "grid",
    placeItems: "center",
    padding: 18,
    zIndex: 9999,
  },
  modal: {
    width: "min(820px, 100%)",
    background: "#fff",
    border: "1px solid #e9e9ee",
    borderRadius: 16,
    boxShadow: "0 20px 60px rgba(0,0,0,0.25)",
    overflow: "hidden",
  },
  header: {
    padding: "14px 16px",
    borderBottom: "1px solid #eef2f7",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  title: { fontSize: 18, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 2, color: "#6b7280", fontSize: 13 },
  closeBtn: {
    height: 36,
    width: 36,
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    cursor: "pointer",
    fontWeight: 900,
  },
  body: { padding: 16 },
  blockTitle: { fontWeight: 900, color: "#0b1b3a", marginBottom: 10 },
  grid2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 },
  field: { display: "flex", flexDirection: "column", gap: 6, minWidth: 0 },
  label: { fontSize: 12, color: "#667085", fontWeight: 800 },
  input: {
    height: 40,
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    padding: "0 12px",
    outline: "none",
    fontSize: 14,
    width: "100%",
  },
  select: {
    height: 40,
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    padding: "0 10px",
    outline: "none",
    fontSize: 14,
    background: "#fff",
    width: "100%",
  },
  infoCard: {
    border: "1px solid #eef2f7",
    background: "#fafafa",
    borderRadius: 14,
    padding: 12,
    marginBottom: 12,
  },
  error: {
    background: "#fff2f2",
    border: "1px solid #ffd1d1",
    color: "#b42318",
    padding: 10,
    borderRadius: 12,
    fontSize: 13,
    marginBottom: 12,
  },
  footer: {
    padding: "12px 16px",
    borderTop: "1px solid #eef2f7",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    background: "#fff",
  },
  primaryBtn: {
    height: 40,
    padding: "0 14px",
    borderRadius: 12,
    border: "1px solid #0b5cff",
    background: "#0b5cff",
    color: "#fff",
    fontWeight: 900,
    cursor: "pointer",
  },
  secondaryBtn: {
    height: 40,
    padding: "0 14px",
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    color: "#111827",
    fontWeight: 900,
    cursor: "pointer",
  },
};
