import { useEffect, useMemo, useState } from "react";
import { api } from "../api/api";

function useDebounced(value, delay = 300) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return v;
}

export default function AsignarEquipoModal({ open, onClose, equipo, onAssigned }) {
  const [q, setQ] = useState("");
  const dq = useDebounced(q, 300);

  const [funcionarios, setFuncionarios] = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [motivo, setMotivo] = useState("");

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const canSave = Boolean(selectedId) && !saving;

  useEffect(() => {
    if (!open) return;
    setErr("");
    setSelectedId("");
    setMotivo("");
    setQ("");
  }, [open]);

  useEffect(() => {
    if (!open) return;

    let mounted = true;
    async function load() {
      setLoading(true);
      setErr("");
      try {
        const res = await api.get("/funcionarios/", {
          params: dq.trim() ? { search: dq.trim() } : {},
        });
        const list = res.data?.results ?? res.data ?? [];
        if (mounted) setFuncionarios(list);
      } catch (e) {
        const msg = e?.response?.data?.detail || e?.message || "Error cargando funcionarios";
        if (mounted) setErr(msg);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    load();
    return () => {
      mounted = false;
    };
  }, [open, dq]);

  async function handleAsignar() {
    if (!equipo?.id_equipo) return;

    setSaving(true);
    setErr("");
    try {
      const payload = {
        id_equipo_id: equipo.id_equipo,
        id_funcionario_id: Number(selectedId),
        fecha_asignacion: new Date().toISOString().slice(0, 10),
        motivo_asignacion: motivo || null,
        estado_asignacion: "ACTIVA",
        activo: true,
      };

      await api.post("/asignaciones/", payload);

      onAssigned?.();
      onClose?.();
    } catch (e) {
      const data = e?.response?.data;
      const msg =
        (typeof data === "string" && data) ||
        data?.detail ||
        (data && JSON.stringify(data)) ||
        e?.message ||
        "No se pudo asignar";
      setErr(msg);
    } finally {
      setSaving(false);
    }
  }

  if (!open) return null;

  return (
    <div style={styles.backdrop} onMouseDown={onClose}>
      <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
        <div style={styles.header}>
          <div>
            <div style={styles.title}>Asignar equipo</div>
            <div style={styles.sub}>
              {equipo?.numero_inventario || "—"} · {equipo?.modelo || "—"}
            </div>
          </div>

          <button style={styles.closeBtn} onClick={onClose} title="Cerrar">
            ✕
          </button>
        </div>

        <div style={styles.body}>
          <div style={styles.field}>
            <div style={styles.label}>Buscar funcionario</div>
            <input
              style={styles.input}
              placeholder="Nombre, RUT o correo..."
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Seleccionar funcionario</div>
            <select
              style={styles.select}
              value={selectedId}
              onChange={(e) => setSelectedId(e.target.value)}
              disabled={loading}
            >
              <option value="">{loading ? "Cargando..." : "Selecciona..."}</option>
              {funcionarios.map((f) => (
                <option key={f.id_funcionario} value={f.id_funcionario}>
                  {f.nombre_completo} · {f.rut}
                </option>
              ))}
            </select>
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Motivo (opcional)</div>
            <textarea
              style={styles.textarea}
              rows={3}
              value={motivo}
              onChange={(e) => setMotivo(e.target.value)}
              placeholder="Ej: Asignación por renovación de equipo..."
            />
          </div>

          {err ? <div style={styles.error}>{err}</div> : null}
        </div>

        <div style={styles.footer}>
          <button style={styles.secondaryBtn} onClick={onClose}>
            Cancelar
          </button>

          <button style={styles.primaryBtn} disabled={!canSave} onClick={handleAsignar}>
            {saving ? "Asignando..." : "Asignar"}
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  backdrop: {
    position: "fixed",
    inset: 0,
    background: "rgba(15, 23, 42, 0.45)",
    display: "grid",
    placeItems: "center",
    padding: 18,
    zIndex: 9999,
  },
  modal: {
    width: "min(720px, 100%)",
    background: "#fff",
    border: "1px solid #e9e9ee",
    borderRadius: 16,
    boxShadow: "0 20px 60px rgba(0,0,0,0.25)",
    overflow: "hidden",
  },
  header: {
    padding: "14px 16px",
    borderBottom: "1px solid #eef2f7",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  title: { fontSize: 18, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 2, color: "#6b7280", fontSize: 13 },
  closeBtn: {
    height: 36,
    width: 36,
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    cursor: "pointer",
    fontWeight: 900,
  },
  body: { padding: 16, display: "flex", flexDirection: "column", gap: 12 },
  field: { display: "flex", flexDirection: "column", gap: 6 },
  label: { fontSize: 12, color: "#667085", fontWeight: 800 },
  input: { height: 40, borderRadius: 12, border: "1px solid #e5e7eb", padding: "0 12px", fontSize: 14, outline: "none" },
  select: { height: 40, borderRadius: 12, border: "1px solid #e5e7eb", padding: "0 10px", fontSize: 14, outline: "none", background: "#fff" },
  textarea: { borderRadius: 12, border: "1px solid #e5e7eb", padding: 12, fontSize: 14, outline: "none", resize: "vertical" },
  error: { background: "#fff2f2", border: "1px solid #ffd1d1", color: "#b42318", padding: 10, borderRadius: 12, fontSize: 13 },
  footer: {
    padding: "12px 16px",
    borderTop: "1px solid #eef2f7",
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    background: "#fff",
  },
  primaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #0b5cff", background: "#0b5cff", color: "#fff", fontWeight: 900, cursor: "pointer" },
  secondaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 900, cursor: "pointer" },
};
