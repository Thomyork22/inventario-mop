import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Boxes,
  Wrench,
  Users,
  FileText,
  Settings,
} from "lucide-react";

const items = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/inventario", label: "Inventario", icon: Boxes },
  { to: "/mantenciones", label: "Mantenciones", icon: Wrench },
  { to: "/funcionarios", label: "Funcionarios", icon: Users },
  { to: "/reportes", label: "Reportes", icon: FileText },
  { to: "/configuracion", label: "Configuración", icon: Settings },
];

export default function Sidebar() {
  return (
    <aside style={styles.aside}>
      <div style={styles.brand}>
        <div style={styles.logo} />
        <div>
          <div style={styles.title}>MOP Inventario TI</div>
        </div>
      </div>

      <nav style={styles.nav}>
        {items.map((it) => {
          const Icon = it.icon;
          return (
            <NavLink
              key={it.to}
              to={it.to}
              style={({ isActive }) => ({
                ...styles.link,
                ...(isActive ? styles.linkActive : {}),
              })}
            >
              <Icon size={18} />
              <span>{it.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}

const styles = {
  aside: {
    width: 250,
    background: "#fff",
    borderRight: "1px solid #e9e9ee",
    padding: 16,
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "8px 6px 16px 6px",
    borderBottom: "1px solid #f0f0f4",
    marginBottom: 12,
  },
  logo: {
    width: 28,
    height: 28,
    borderRadius: 6,
    background: "#1667ff",
  },
  title: {
    fontWeight: 700,
    color: "#0b1b3a",
    fontSize: 14,
    lineHeight: "16px",
  },
  nav: {
    display: "flex",
    flexDirection: "column",
    gap: 6,
    marginTop: 12,
  },
  link: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "10px 10px",
    borderRadius: 10,
    textDecoration: "none",
    color: "#333",
    fontSize: 14,
  },
  linkActive: {
    background: "#eef4ff",
    color: "#0b4edb",
    fontWeight: 600,
  },
};
