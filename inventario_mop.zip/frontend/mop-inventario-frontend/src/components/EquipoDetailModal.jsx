import { useEffect } from "react";

export default function EquipoDetailModal({
  open,
  onClose,
  equipo,
  onAssign,
  onEdit,
}) {
  // Cerrar con ESC
  useEffect(() => {
    if (!open) return;
    function onKey(e) {
      if (e.key === "Escape") onClose?.();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div style={styles.backdrop} onMouseDown={onClose}>
      <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
        <div style={styles.header}>
          <div>
            <div style={styles.title}>Detalle de equipo</div>
            <div style={styles.sub}>
              {equipo?.numero_inventario || "—"} · {equipo?.modelo || "—"}
            </div>
          </div>

          <button style={styles.closeBtn} onClick={onClose} title="Cerrar">
            ✕
          </button>
        </div>

        <div style={styles.body}>
          {/* Columna 1 */}
          <div style={styles.col}>
            <Field label="ID" value={equipo?.id_equipo} />
            <Field label="Inventario" value={equipo?.numero_inventario} />
            <Field label="Serie" value={equipo?.numero_serie} mono />
            <Field label="Modelo" value={equipo?.modelo} />
            <Field label="Activo" value={equipo?.activo ? "Sí" : "No"} />
          </div>

          {/* Columna 2 */}
          <div style={styles.col}>
            <Field label="Tipo" value={equipo?.tipo_equipo?.descripcion} />
            <Field label="Marca" value={equipo?.marca?.descripcion} />
            <Field label="Estado" value={equipo?.estado?.descripcion} pill />
            <Field label="Ubicación" value={equipo?.ubicacion?.nombre_sede} />
            <Field label="Región" value={equipo?.ubicacion?.region?.nombre || "—"} />
          </div>

          {/* Columna 3 */}
          <div style={styles.col}>
            <Field label="Proveedor" value={equipo?.proveedor || "—"} />
            <Field label="Factura" value={equipo?.numero_factura || "—"} />
            <Field label="Garantía (meses)" value={equipo?.garantia_meses ?? "—"} />
            <Field label="Fecha compra" value={equipo?.fecha_compra || "—"} />
            <Field label="Obs." value={equipo?.observaciones || "—"} multiline />
          </div>
        </div>

        <div style={styles.footer}>
          <button style={styles.secondaryBtn} onClick={onClose}>
            Cerrar
          </button>

          <div style={{ display: "flex", gap: 10 }}>
            <button
              style={styles.secondaryBtn}
              onClick={() => onEdit?.(equipo)}
              title="Editar datos del equipo"
            >
              Editar
            </button>

            <button
              style={styles.primaryBtn}
              onClick={() => onAssign?.(equipo)}
              title="Asignar equipo a funcionario"
            >
              Asignar / Devolver
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, mono, multiline, pill }) {
  return (
    <div style={styles.field}>
      <div style={styles.label}>{label}</div>
      <div
        style={{
          ...styles.value,
          ...(mono ? styles.mono : {}),
          ...(multiline ? styles.multiline : {}),
        }}
      >
        {pill ? <span style={pillStyle(value)}>{value || "—"}</span> : value || "—"}
      </div>
    </div>
  );
}

function pillStyle(label) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    padding: "6px 10px",
    borderRadius: 999,
    fontSize: 12,
    fontWeight: 800,
    border: "1px solid #e9e9ee",
    background: "#fff",
    color: "#111827",
  };
  const l = (label || "").toLowerCase();
  if (l.includes("ocup"))
    return { ...base, background: "#fff7ed", borderColor: "#fed7aa", color: "#9a3412" };
  if (l.includes("libre") || l.includes("dispon"))
    return { ...base, background: "#ecfdf3", borderColor: "#abefc6", color: "#067647" };
  if (l.includes("baja"))
    return { ...base, background: "#fff1f2", borderColor: "#fecdd3", color: "#9f1239" };
  return base;
}

const styles = {
  backdrop: {
    position: "fixed",
    inset: 0,
    background: "rgba(15, 23, 42, 0.45)",
    display: "grid",
    placeItems: "center",
    padding: 18,
    zIndex: 9999,
  },
  modal: {
    width: "min(1100px, 100%)",
    background: "#fff",
    border: "1px solid #e9e9ee",
    borderRadius: 16,
    boxShadow: "0 20px 60px rgba(0,0,0,0.25)",
    overflow: "hidden",
  },
  header: {
    padding: "14px 16px",
    borderBottom: "1px solid #eef2f7",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  title: { fontSize: 18, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 2, color: "#6b7280", fontSize: 13 },
  closeBtn: {
    height: 36,
    width: 36,
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    cursor: "pointer",
    fontWeight: 900,
  },
  body: {
    padding: 16,
    display: "grid",
    gridTemplateColumns: "1fr 1fr 1fr",
    gap: 12,
  },
  col: {
    background: "#fafafa",
    border: "1px solid #eef2f7",
    borderRadius: 14,
    padding: 12,
  },
  field: { marginBottom: 10 },
  label: { fontSize: 12, color: "#667085", fontWeight: 800, marginBottom: 6 },
  value: { fontSize: 14, color: "#111827" },
  mono: { fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace" },
  multiline: { whiteSpace: "pre-wrap" },

  footer: {
    padding: "12px 16px",
    borderTop: "1px solid #eef2f7",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    background: "#fff",
  },
  primaryBtn: {
    height: 40,
    padding: "0 14px",
    borderRadius: 12,
    border: "1px solid #0b5cff",
    background: "#0b5cff",
    color: "#fff",
    fontWeight: 900,
    cursor: "pointer",
  },
  secondaryBtn: {
    height: 40,
    padding: "0 14px",
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    color: "#111827",
    fontWeight: 900,
    cursor: "pointer",
  },
};
