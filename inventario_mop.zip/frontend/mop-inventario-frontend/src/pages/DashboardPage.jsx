import { useEffect, useMemo, useState } from "react";
import { api } from "../api/api";

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [historial, setHistorial] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  async function loadAll() {
    setLoading(true);
    setErr("");
    try {
      const [statsRes, histRes] = await Promise.all([
        api.get("/dashboard/stats/"),
        api.get("/historial-estados/", {
          params: { ordering: "-id_historial_estado", page: 1 },
        }),
      ]);

      setStats(statsRes.data);

      const list = histRes.data?.results ?? histRes.data ?? [];
      setHistorial(list.slice(0, 8));
    } catch (e) {
      setErr(e?.response?.data?.detail || e?.message || "Error cargando dashboard");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
  }, []);

  const sedeData = useMemo(() => stats?.por_sede ?? [], [stats]);
  const maxSede = useMemo(() => {
    if (!sedeData.length) return 1;
    return Math.max(...sedeData.map((x) => x.total || 0), 1);
  }, [sedeData]);

  return (
    <div>
      {/* Header */}
      <div style={styles.headerRow}>
        <div>
          <h1 style={styles.title}>Dashboard</h1>
          <div style={styles.sub}>
            Resumen inteligente del inventario · estados · sedes · garantías.
          </div>
        </div>

        <div style={styles.headerActions}>
          <button style={styles.secondaryBtn} onClick={loadAll} disabled={loading}>
            {loading ? "Actualizando…" : "Actualizar"}
          </button>

          <button
            style={styles.primaryBtn}
            onClick={() => (window.location.href = "/inventario")}
            title="Ir a Inventario"
          >
            Ir a Inventario →
          </button>
        </div>
      </div>

      {/* Estado */}
      {err ? <div style={styles.error}>{err}</div> : null}

      {/* KPIs */}
      <div style={styles.kpiGrid}>
        <KpiCard
          title="Total equipos"
          value={loading ? "—" : stats?.total ?? 0}
          hint="Registrados en el sistema"
          icon="📦"
        />
        <KpiCard
          title="Libres"
          value={loading ? "—" : stats?.libres ?? 0}
          hint="Disponibles para asignación"
          icon="🟢"
        />
        <KpiCard
          title="Ocupados"
          value={loading ? "—" : stats?.ocupados ?? 0}
          hint="Asignados a funcionario"
          icon="🔵"
        />
        <KpiCard
          title="En mantenimiento"
          value={loading ? "—" : stats?.mantenimiento ?? 0}
          hint="Revisando/diagnóstico/taller"
          icon="🛠️"
        />
        <KpiCard
          title="Garantías por vencer"
          value={loading ? "—" : stats?.garantias_por_vencer ?? 0}
          hint="Próximos 30 días"
          icon="⏳"
          accent="warn"
        />
      </div>

      {/* Layout principal */}
      <div style={styles.mainGrid}>
        {/* Chart por sede */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <div>
              <div style={styles.cardTitle}>Equipos por sede</div>
              <div style={styles.cardSub}>Distribución (top sedes)</div>
            </div>

            <button
              style={styles.smallBtn}
              onClick={() => (window.location.href = "/inventario")}
              title="Ver detalle en Inventario"
            >
              Ver detalle
            </button>
          </div>

          <div style={{ padding: 14 }}>
            {!loading && sedeData.length === 0 ? (
              <div style={styles.empty}>No hay datos de sedes aún.</div>
            ) : (
              <div style={{ display: "grid", gap: 10 }}>
                {sedeData.slice(0, 8).map((x, idx) => {
                  const pctBar = Math.round(((x.total || 0) / maxSede) * 100);
                  const pctTotal = stats?.total
                    ? Math.round(((x.total || 0) / stats.total) * 100)
                    : 0;

                  return (
                    <button
                      key={`${x.sede}-${idx}`}
                      style={styles.barRowBtn}
                      onClick={() => {
                        const id = x?.id_ubicacion;
                        window.location.href = id
                          ? `/inventario?id_ubicacion=${id}`
                          : `/inventario`;
                      }}
                      title="Ver inventario de esta sede"
                    >
                      <div style={styles.barLabelWrap}>
                        <div style={styles.barLabelLine}>
                          <span style={styles.barLabelText}>{x.sede}</span>
                          <span style={styles.barPct}>({pctTotal}%)</span>
                        </div>

                        <div style={styles.barMini}>
                          <span style={styles.badge}>🟢 {x.libres ?? 0}</span>
                          <span style={styles.badge}>🔵 {x.ocupados ?? 0}</span>
                          <span style={styles.badge}>🛠️ {x.mantenimiento ?? 0}</span>
                        </div>
                      </div>

                      <div style={styles.barTrack}>
                        <div style={{ ...styles.barFill, width: `${pctBar}%` }} />
                      </div>

                      <div style={styles.barValue}>{x.total}</div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Actividad reciente */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <div>
              <div style={styles.cardTitle}>Últimos movimientos</div>
              <div style={styles.cardSub}>Cambios recientes de estado</div>
            </div>

            <button style={styles.smallBtn} onClick={loadAll} disabled={loading}>
              {loading ? "…" : "Refrescar"}
            </button>
          </div>

          <div style={{ padding: 14 }}>
            {!loading && historial.length === 0 ? (
              <div style={styles.empty}>Aún no hay movimientos registrados.</div>
            ) : (
              <div style={styles.activityList}>
                {historial.map((h) => (
                  <div key={h.id_historial_estado} style={styles.activityItem}>
                    <div style={styles.activityLeft}>
                      <div style={styles.activityTitle}>
                        <span style={styles.mono}>
                          {h?.equipo?.numero_inventario || "—"}
                        </span>

                        <span style={{ margin: "0 8px", color: "#98a2b3" }}>→</span>

                        <span style={styles.pill}>
                          {h?.estado_nuevo?.descripcion || "Estado"}
                        </span>
                      </div>

                      <div style={styles.activitySub}>
                        {h?.motivo_detallado || "—"}
                      </div>
                    </div>

                    <div style={styles.activityRight}>
                      <div style={styles.activityDate}>
                        {formatDateTime(h?.fecha_cambio)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Acciones rápidas */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <div>
              <div style={styles.cardTitle}>Acciones rápidas</div>
              <div style={styles.cardSub}>Atajos típicos del flujo</div>
            </div>
          </div>

          <div style={{ padding: 14, display: "grid", gap: 10 }}>
            <QuickAction
              title="Gestionar inventario"
              desc="Buscar, filtrar y abrir detalles de equipos"
              onClick={() => (window.location.href = "/inventario")}
              icon="📋"
            />
            <QuickAction
              title="Crear equipo nuevo"
              desc="Ingresar un equipo al inventario"
              onClick={() => (window.location.href = "/inventario")}
              icon="➕"
            />
            <QuickAction
              title="Ver asignaciones"
              desc="Revisar asignaciones activas y devoluciones"
              onClick={() => (window.location.href = "/inventario")}
              icon="👤"
            />
          </div>
        </div>

        {/* Tip “inteligente” */}
        <div style={{ ...styles.card, background: "#0b5cff", borderColor: "#0b5cff" }}>
          <div style={{ padding: 16, color: "#fff" }}>
            <div style={{ fontWeight: 900, fontSize: 16 }}>Insight</div>
            <div style={{ marginTop: 8, opacity: 0.9, lineHeight: 1.4 }}>
              Prioriza las <b>garantías por vencer</b> y equipos <b>en mantenimiento</b>.
              Así reduces costos y evitas pérdidas por vencimientos.
            </div>

            <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
              <button
                style={{
                  ...styles.secondaryBtn,
                  borderColor: "rgba(255,255,255,0.3)",
                  color: "#fff",
                  background: "transparent",
                }}
                onClick={() => (window.location.href = "/inventario")}
              >
                Revisar en Inventario
              </button>
              <button
                style={{
                  ...styles.secondaryBtn,
                  borderColor: "rgba(255,255,255,0.2)",
                  background: "rgba(255,255,255,0.15)",
                  color: "#fff",
                }}
                onClick={loadAll}
                disabled={loading}
              >
                {loading ? "…" : "Actualizar datos"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div style={styles.note}>
        Siguiente módulo recomendado: <b>Mantenimientos</b> (lista + crear + filtro por equipo).
      </div>
    </div>
  );
}

/* ---------------- UI Pieces ---------------- */

function KpiCard({ title, value, hint, icon, accent }) {
  return (
    <div style={{ ...styles.kpiCard, ...(accent === "warn" ? styles.kpiWarn : {}) }}>
      <div style={styles.kpiTop}>
        <div style={styles.kpiTitle}>{title}</div>
        <div style={styles.kpiIcon}>{icon}</div>
      </div>
      <div style={styles.kpiValue}>{value}</div>
      <div style={styles.kpiHint}>{hint}</div>
    </div>
  );
}

function QuickAction({ title, desc, onClick, icon }) {
  return (
    <button style={styles.quickAction} onClick={onClick}>
      <div style={styles.quickIcon}>{icon}</div>
      <div style={{ textAlign: "left" }}>
        <div style={styles.quickTitle}>{title}</div>
        <div style={styles.quickDesc}>{desc}</div>
      </div>
      <div style={styles.quickArrow}>→</div>
    </button>
  );
}

function formatDateTime(v) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${dd}-${mm}-${yyyy} ${hh}:${mi}`;
}

/* ---------------- Styles ---------------- */

const styles = {
  headerRow: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, marginBottom: 14 },
  title: { margin: 0, fontSize: 34, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 6, color: "#6b7280", fontSize: 14 },
  headerActions: { display: "flex", gap: 10, alignItems: "center" },

  primaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #0b5cff", background: "#0b5cff", color: "#fff", fontWeight: 900, cursor: "pointer" },
  secondaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" },
  smallBtn: { height: 34, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" },

  error: {
    background: "#fff2f2",
    border: "1px solid #ffd1d1",
    color: "#b42318",
    padding: 10,
    borderRadius: 12,
    fontSize: 13,
    marginBottom: 12,
  },

  kpiGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(5, minmax(0, 1fr))",
    gap: 12,
    marginBottom: 12,
  },
  kpiCard: {
    background: "#fff",
    border: "1px solid #e9e9ee",
    borderRadius: 16,
    padding: 14,
    boxShadow: "0 10px 24px rgba(0,0,0,0.04)",
  },
  kpiWarn: { borderColor: "#fed7aa", background: "#fff7ed" },
  kpiTop: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 },
  kpiTitle: { fontSize: 12, fontWeight: 900, color: "#667085" },
  kpiIcon: { fontSize: 18 },
  kpiValue: { marginTop: 10, fontSize: 26, fontWeight: 1000, color: "#0b1b3a" },
  kpiHint: { marginTop: 4, fontSize: 12, color: "#6b7280" },

  mainGrid: {
    display: "grid",
    gridTemplateColumns: "1.2fr 0.8fr",
    gap: 12,
    alignItems: "start",
  },

  card: {
    background: "#fff",
    border: "1px solid #e9e9ee",
    borderRadius: 16,
    overflow: "hidden",
    boxShadow: "0 10px 24px rgba(0,0,0,0.04)",
  },
  cardHeader: {
    padding: "14px 16px",
    borderBottom: "1px solid #eef2f7",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    background: "#fafafa",
  },
  cardTitle: { fontSize: 14, fontWeight: 1000, color: "#0b1b3a" },
  cardSub: { marginTop: 2, fontSize: 12, color: "#6b7280" },

  empty: { padding: 12, border: "1px dashed #e5e7eb", borderRadius: 12, color: "#6b7280", fontSize: 13, background: "#fff" },

  // ✅ barras clickeables + info
  barRowBtn: {
    display: "grid",
    gridTemplateColumns: "170px 1fr 50px",
    gap: 10,
    alignItems: "center",
    border: "none",
    background: "transparent",
    padding: 0,
    cursor: "pointer",
    textAlign: "left",
  },
  barLabelWrap: { minWidth: 0 },
  barLabelLine: { display: "flex", alignItems: "center", gap: 6, minWidth: 0 },
  barLabelText: { fontSize: 13, color: "#111827", fontWeight: 900, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  barPct: { color: "#667085", fontWeight: 900, fontSize: 12, flex: "0 0 auto" },

  barMini: { marginTop: 6, display: "flex", gap: 8, flexWrap: "wrap" },
  badge: {
    fontSize: 12,
    fontWeight: 900,
    color: "#344054",
    background: "#f2f4f7",
    border: "1px solid #eaecf0",
    padding: "4px 8px",
    borderRadius: 999,
  },

  barTrack: { height: 12, borderRadius: 999, background: "#eef2f7", overflow: "hidden", border: "1px solid #e5e7eb" },
  barFill: { height: "100%", borderRadius: 999, background: "#0b5cff" },
  barValue: { textAlign: "right", fontSize: 13, fontWeight: 900, color: "#0b1b3a" },

  activityList: { display: "grid", gap: 10 },
  activityItem: {
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    padding: 12,
    borderRadius: 14,
    border: "1px solid #eef2f7",
    background: "#fff",
  },
  activityLeft: { minWidth: 0 },
  activityTitle: { display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" },
  activitySub: { marginTop: 6, fontSize: 12, color: "#6b7280" },
  activityRight: { textAlign: "right" },
  activityDate: { fontSize: 12, color: "#667085", fontWeight: 800 },

  mono: { fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace", fontWeight: 900, color: "#0b1b3a" },
  pill: {
    display: "inline-flex",
    alignItems: "center",
    padding: "6px 10px",
    borderRadius: 999,
    fontSize: 12,
    fontWeight: 900,
    border: "1px solid #dbeafe",
    background: "#eef4ff",
    color: "#0b4edb",
  },

  quickAction: {
    width: "100%",
    display: "grid",
    gridTemplateColumns: "40px 1fr 24px",
    alignItems: "center",
    gap: 10,
    padding: 12,
    borderRadius: 14,
    border: "1px solid #eef2f7",
    background: "#fff",
    cursor: "pointer",
    textAlign: "left",
  },
  quickIcon: { fontSize: 18, display: "grid", placeItems: "center" },
  quickTitle: { fontWeight: 1000, color: "#0b1b3a" },
  quickDesc: { marginTop: 2, fontSize: 12, color: "#6b7280" },
  quickArrow: { fontWeight: 1000, color: "#98a2b3", textAlign: "right" },

  note: { marginTop: 12, color: "#6b7280", fontSize: 13 },
};