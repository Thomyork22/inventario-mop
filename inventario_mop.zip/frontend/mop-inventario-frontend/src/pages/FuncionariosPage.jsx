import { useEffect, useMemo, useState } from "react";
import { api } from "../api/api";

export default function FuncionariosPage() {
  // ---- data ----
  const [rows, setRows] = useState([]);
  const [count, setCount] = useState(0);

  // ---- ui ----
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // ---- filtros/paginación ----
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const [q, setQ] = useState("");

  // ---- modal: nuevo ----
  const [openNew, setOpenNew] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formErr, setFormErr] = useState("");
  const [form, setForm] = useState({
    rut: "",
    nombre_completo: "",
    email_institucional: "",
    telefono: "",
    codigo_cargo_id: "",
    codigo_unidad_id: "",
    fecha_ingreso: "",
    activo: true,
  });

  // ---- modal: ver / editar ----
  const [openView, setOpenView] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [active, setActive] = useState(null);

  const [editSaving, setEditSaving] = useState(false);
  const [editErr, setEditErr] = useState("");
  const [editForm, setEditForm] = useState({
    rut: "",
    nombre_completo: "",
    email_institucional: "",
    telefono: "",
    codigo_cargo_id: "",
    codigo_unidad_id: "",
    fecha_ingreso: "",
    fecha_salida: "",
    activo: true,
  });

  // ---- asignaciones (equipo actual + historial) ----
  const [asigLoading, setAsigLoading] = useState(false);
  const [asignaciones, setAsignaciones] = useState([]); // historial

  const equipoActual = useMemo(() => {
    const list = Array.isArray(asignaciones) ? asignaciones : [];

    // 1) Si el backend trae activo true, eso manda
    const byActivo = list.find((a) => a?.activo === true);
    if (byActivo) return byActivo;

    // 2) Si no hay devolución, probablemente es la actual
    const byNoDevol = list.find((a) => !a?.fecha_devolucion);
    if (byNoDevol) return byNoDevol;

    // 3) fallback: última (ya viene ordenada desc)
    return list[0] || null;
  }, [asignaciones]);

  async function loadFuncionarios(p = page) {
    setLoading(true);
    setErr("");
    try {
      const params = { ordering: "-id_funcionario", page: p };
      if (q?.trim()) params.search = q.trim();

      const res = await api.get("/funcionarios/", { params });
      const list = res.data?.results ?? res.data ?? [];
      const total = res.data?.count ?? list.length;

      setRows(list);
      setCount(total);
    } catch (e) {
      setErr(e?.response?.data?.detail || e?.message || "Error cargando funcionarios");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadFuncionarios(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const totalPages = useMemo(() => Math.max(Math.ceil((count || 0) / pageSize), 1), [count]);

  function openNewModal() {
    setFormErr("");
    setForm({
      rut: "",
      nombre_completo: "",
      email_institucional: "",
      telefono: "",
      codigo_cargo_id: "",
      codigo_unidad_id: "",
      fecha_ingreso: "",
      activo: true,
    });
    setOpenNew(true);
  }

  async function createFuncionario() {
    setSaving(true);
    setFormErr("");
    try {
      if (!form.rut?.trim()) return setFormErr("Ingresa RUT.");
      if (!form.nombre_completo?.trim()) return setFormErr("Ingresa nombre completo.");
      if (!form.email_institucional?.trim()) return setFormErr("Ingresa email institucional.");

      const payload = {
        rut: form.rut.trim(),
        nombre_completo: form.nombre_completo.trim(),
        email_institucional: form.email_institucional.trim(),
        telefono: form.telefono?.trim() || "",
        codigo_cargo_id: form.codigo_cargo_id ? Number(form.codigo_cargo_id) : null,
        codigo_unidad_id: form.codigo_unidad_id ? Number(form.codigo_unidad_id) : null,
        fecha_ingreso: form.fecha_ingreso || null,
        activo: Boolean(form.activo),
      };

      await api.post("/funcionarios/", payload);

      setOpenNew(false);
      setPage(1);
      await loadFuncionarios(1);
    } catch (e) {
      const data = e?.response?.data;
      if (data && typeof data === "object") {
        const firstKey = Object.keys(data)[0];
        const msg = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
        setFormErr(msg || "No se pudo crear el funcionario.");
      } else {
        setFormErr(e?.message || "No se pudo crear el funcionario.");
      }
    } finally {
      setSaving(false);
    }
  }

  async function loadAsignacionesFuncionario(funcionario) {
    const id = funcionario?.id_funcionario ?? null;
    if (!id) {
      setAsignaciones([]);
      return;
    }

    setAsigLoading(true);
    try {
      const res = await api.get("/asignaciones/", {
        params: {
          id_funcionario: id,
          ordering: "-id_asignacion",
        },
      });

      const list = res.data?.results ?? res.data ?? [];
      setAsignaciones(Array.isArray(list) ? list : []);
    } catch {
      setAsignaciones([]);
    } finally {
      setAsigLoading(false);
    }
  }

  async function openViewModal(f) {
    setActive(f);
    setOpenView(true);
    await loadAsignacionesFuncionario(f);
  }

  function openEditModal(f) {
    setActive(f);
    setEditErr("");
    setEditForm({
      rut: f?.rut || "",
      nombre_completo: f?.nombre_completo || "",
      email_institucional: f?.email_institucional || "",
      telefono: f?.telefono || "",
      codigo_cargo_id: String(f?.codigo_cargo ?? f?.cargo?.codigo_cargo ?? "") || "",
      codigo_unidad_id: String(f?.codigo_unidad ?? f?.unidad?.codigo_unidad ?? "") || "",
      fecha_ingreso: f?.fecha_ingreso || "",
      fecha_salida: f?.fecha_salida || "",
      activo: f?.activo ?? true,
    });
    setOpenEdit(true);
    loadAsignacionesFuncionario(f);
  }

  async function saveEdit() {
    if (!active?.id_funcionario) return;

    setEditSaving(true);
    setEditErr("");
    try {
      const payload = {
        rut: editForm.rut?.trim() || "",
        nombre_completo: editForm.nombre_completo?.trim() || "",
        email_institucional: editForm.email_institucional?.trim() || "",
        telefono: editForm.telefono?.trim() || "",
        codigo_cargo_id: editForm.codigo_cargo_id ? Number(editForm.codigo_cargo_id) : null,
        codigo_unidad_id: editForm.codigo_unidad_id ? Number(editForm.codigo_unidad_id) : null,
        fecha_ingreso: editForm.fecha_ingreso || null,
        fecha_salida: editForm.fecha_salida || null,
        activo: Boolean(editForm.activo),
      };

      await api.patch(`/funcionarios/${active.id_funcionario}/`, payload);

      setOpenEdit(false);
      await loadFuncionarios(page);
    } catch (e) {
      const data = e?.response?.data;
      if (data && typeof data === "object") {
        const firstKey = Object.keys(data)[0];
        const msg = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
        setEditErr(msg || "No se pudo guardar.");
      } else {
        setEditErr(e?.message || "No se pudo guardar.");
      }
    } finally {
      setEditSaving(false);
    }
  }

  async function quickToggleActivo(f) {
    if (!f?.id_funcionario) return;
    try {
      await api.patch(`/funcionarios/${f.id_funcionario}/`, { activo: !Boolean(f.activo) });
      await loadFuncionarios(page);
    } catch (e) {
      setErr(e?.response?.data?.detail || e?.message || "No se pudo cambiar estado.");
    }
  }

  return (
    <div>
      {/* Header */}
      <div style={styles.headerRow}>
        <div>
          <h1 style={styles.title}>Funcionarios</h1>
          <div style={styles.sub}>Gestiona funcionarios y revisa el equipo/PC asignado (actual + historial).</div>
        </div>

        <div style={styles.headerActions}>
          <button style={styles.secondaryBtn} onClick={() => loadFuncionarios(page)} disabled={loading}>
            {loading ? "Actualizando…" : "Actualizar"}
          </button>
          <button style={styles.primaryBtn} onClick={openNewModal}>
            + Nuevo funcionario
          </button>
        </div>
      </div>

      {err ? <div style={styles.error}>{err}</div> : null}

      {/* Filtros */}
      <div style={styles.filtersCard}>
        <div style={styles.filtersGrid}>
          <div>
            <div style={styles.label}>Buscar</div>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  setPage(1);
                  loadFuncionarios(1);
                }
              }}
              placeholder="RUT / nombre / email…"
              style={styles.input}
            />
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <button
                style={styles.smallBtn}
                onClick={() => {
                  setPage(1);
                  loadFuncionarios(1);
                }}
                disabled={loading}
              >
                Buscar
              </button>
              <button
                style={styles.smallBtn}
                onClick={() => {
                  setQ("");
                  setPage(1);
                  loadFuncionarios(1);
                }}
                disabled={loading}
              >
                Limpiar
              </button>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "flex-end" }}>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <button
                style={styles.smallBtn}
                onClick={() => {
                  const p = Math.max(page - 1, 1);
                  setPage(p);
                  loadFuncionarios(p);
                }}
                disabled={loading || page <= 1}
              >
                ←
              </button>

              <div style={styles.pagePill}>
                Página <b>{page}</b> / {totalPages}
              </div>

              <button
                style={styles.smallBtn}
                onClick={() => {
                  const p = Math.min(page + 1, totalPages);
                  setPage(p);
                  loadFuncionarios(p);
                }}
                disabled={loading || page >= totalPages}
              >
                →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabla */}
      <div style={styles.card}>
        <div style={styles.cardHeader}>
          <div>
            <div style={styles.cardTitle}>Listado</div>
            <div style={styles.cardSub}>{loading ? "Cargando…" : `${count || 0} registros`}</div>
          </div>
        </div>

        <div style={{ padding: 14 }}>
          {!loading && rows.length === 0 ? (
            <div style={styles.empty}>No hay funcionarios para mostrar.</div>
          ) : (
            <div style={styles.tableWrap}>
              <table style={styles.table}>
                <thead>
                  <tr>
                    <th style={styles.th}>ID</th>
                    <th style={styles.th}>Funcionario</th>
                    <th style={styles.th}>Email</th>
                    <th style={styles.th}>Estado</th>
                    <th style={styles.thRight}>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((f) => (
                    <tr key={f.id_funcionario}>
                      <td style={styles.tdMono}>{f.id_funcionario}</td>

                      <td style={styles.td}>
                        <div style={{ fontWeight: 1000, color: "#0b1b3a" }}>{f.nombre_completo || "—"}</div>
                        <div style={{ fontSize: 12, color: "#6b7280" }}>{f.rut || "Sin RUT"}</div>
                      </td>

                      <td style={styles.td}>{f.email_institucional || "—"}</td>

                      <td style={styles.td}>
                        <span style={f.activo ? styles.pillOk : styles.pillBad}>{f.activo ? "Activo" : "Inactivo"}</span>
                      </td>

                      <td style={styles.tdRight}>
                        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                          <button style={styles.smallBtn} onClick={() => openViewModal(f)}>
                            Ver
                          </button>
                          <button style={styles.smallBtn} onClick={() => openEditModal(f)}>
                            Editar
                          </button>
                          <button style={styles.smallBtn} onClick={() => quickToggleActivo(f)}>
                            {f.activo ? "Desactivar" : "Activar"}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Nuevo */}
      {openNew ? (
        <div style={styles.modalOverlay} onMouseDown={() => setOpenNew(false)}>
          <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <div>
                <div style={styles.modalTitle}>Nuevo funcionario</div>
                <div style={styles.modalSub}>Crea un funcionario para poder asignarle equipos.</div>
              </div>
              <button style={styles.iconBtn} onClick={() => setOpenNew(false)} title="Cerrar">
                ✕
              </button>
            </div>

            {formErr ? <div style={styles.error}>{formErr}</div> : null}

            <div style={styles.formGrid}>
              <div>
                <div style={styles.label}>RUT *</div>
                <input value={form.rut} onChange={(e) => setForm((p) => ({ ...p, rut: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Nombre completo *</div>
                <input value={form.nombre_completo} onChange={(e) => setForm((p) => ({ ...p, nombre_completo: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Email institucional *</div>
                <input value={form.email_institucional} onChange={(e) => setForm((p) => ({ ...p, email_institucional: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Teléfono</div>
                <input value={form.telefono} onChange={(e) => setForm((p) => ({ ...p, telefono: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Código cargo (opcional)</div>
                <input
                  value={form.codigo_cargo_id}
                  onChange={(e) => setForm((p) => ({ ...p, codigo_cargo_id: e.target.value.replace(/[^\d]/g, "") }))}
                  style={styles.input}
                  placeholder="Ej: 1"
                />
              </div>

              <div>
                <div style={styles.label}>Código unidad (opcional)</div>
                <input
                  value={form.codigo_unidad_id}
                  onChange={(e) => setForm((p) => ({ ...p, codigo_unidad_id: e.target.value.replace(/[^\d]/g, "") }))}
                  style={styles.input}
                  placeholder="Ej: 3"
                />
              </div>

              <div>
                <div style={styles.label}>Fecha ingreso</div>
                <input type="date" value={form.fecha_ingreso || ""} onChange={(e) => setForm((p) => ({ ...p, fecha_ingreso: e.target.value }))} style={styles.input} />
              </div>

              <div style={{ display: "flex", alignItems: "flex-end" }}>
                <label style={styles.checkRow}>
                  <input type="checkbox" checked={Boolean(form.activo)} onChange={(e) => setForm((p) => ({ ...p, activo: e.target.checked }))} />
                  <span style={{ fontWeight: 900 }}>Activo</span>
                </label>
              </div>
            </div>

            <div style={styles.modalFooter}>
              <button style={styles.secondaryBtn} onClick={() => setOpenNew(false)} disabled={saving}>
                Cancelar
              </button>
              <button style={styles.primaryBtn} onClick={createFuncionario} disabled={saving}>
                {saving ? "Guardando…" : "Crear funcionario"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Modal: Ver */}
      {openView && active ? (
        <div style={styles.modalOverlay} onMouseDown={() => setOpenView(false)}>
          <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <div>
                <div style={styles.modalTitle}>{active.nombre_completo || "Funcionario"}</div>
                <div style={styles.modalSub}>
                  {active.rut || "—"} · {active.email_institucional || "—"}
                </div>
              </div>
              <button style={styles.iconBtn} onClick={() => setOpenView(false)} title="Cerrar">
                ✕
              </button>
            </div>

            <div style={{ padding: 16, display: "grid", gap: 12 }}>
              <div style={styles.kvGrid}>
                <KV label="Teléfono" value={active.telefono || "—"} />
                <KV label="Activo" value={active.activo ? "Sí" : "No"} />
                <KV label="Fecha ingreso" value={formatDate(active.fecha_ingreso)} />
              </div>

              <div style={styles.section}>
                <div style={styles.sectionTitle}>Equipo/PC actual asignado</div>

                {asigLoading ? (
                  <div style={styles.help}>Cargando asignaciones…</div>
                ) : !equipoActual?.equipo ? (
                  <div style={styles.help}>Este funcionario no tiene un equipo asignado actualmente.</div>
                ) : (
                  <EquipoCard asignacion={equipoActual} isActual />
                )}
              </div>

              <div style={styles.section}>
                <div style={styles.sectionTitle}>Historial de equipos asignados</div>

                {asigLoading ? (
                  <div style={styles.help}>Cargando historial…</div>
                ) : asignaciones.length === 0 ? (
                  <div style={styles.help}>No hay historial de asignaciones para este funcionario.</div>
                ) : (
                  <div style={styles.histList}>
                    {asignaciones.slice(0, 10).map((a) => {
                      const isActual =
                        (equipoActual?.id_asignacion && a?.id_asignacion === equipoActual.id_asignacion) ||
                        (equipoActual?.equipo?.id_equipo && a?.equipo?.id_equipo === equipoActual.equipo.id_equipo && !a?.fecha_devolucion);

                      return (
                        <div
                          key={a.id_asignacion ?? `${a?.equipo?.id_equipo}-${a?.fecha_asignacion}`}
                          style={isActual ? styles.histItemActive : styles.histItem}
                        >
                          <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                            <div style={{ fontWeight: 1000 }}>
                              {a?.equipo?.numero_inventario || "—"} · {a?.equipo?.modelo || "Sin modelo"}
                            </div>
                            {isActual ? <span style={styles.pillOk}>Actual</span> : <span style={styles.pillNeutral}>Histórico</span>}
                          </div>

                          <div style={{ fontSize: 12, color: "#6b7280", marginTop: 4 }}>
                            {formatDate(a?.fecha_asignacion)} → {a?.fecha_devolucion ? formatDate(a?.fecha_devolucion) : "Actual"}
                            {" · "}
                            {getEstadoAsignacionLabel(a)}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            <div style={styles.modalFooter}>
              <button style={styles.secondaryBtn} onClick={() => setOpenView(false)}>
                Cerrar
              </button>
              <button
                style={styles.primaryBtn}
                onClick={() => {
                  setOpenView(false);
                  openEditModal(active);
                }}
              >
                Editar
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Modal: Editar */}
      {openEdit && active ? (
        <div style={styles.modalOverlay} onMouseDown={() => setOpenEdit(false)}>
          <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <div>
                <div style={styles.modalTitle}>Editar funcionario</div>
                <div style={styles.modalSub}>{active.nombre_completo || "—"}</div>
              </div>
              <button style={styles.iconBtn} onClick={() => setOpenEdit(false)} title="Cerrar">
                ✕
              </button>
            </div>

            {editErr ? <div style={styles.error}>{editErr}</div> : null}

            <div style={styles.formGrid}>
              <div>
                <div style={styles.label}>RUT</div>
                <input value={editForm.rut} onChange={(e) => setEditForm((p) => ({ ...p, rut: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Nombre completo</div>
                <input value={editForm.nombre_completo} onChange={(e) => setEditForm((p) => ({ ...p, nombre_completo: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Email institucional</div>
                <input value={editForm.email_institucional} onChange={(e) => setEditForm((p) => ({ ...p, email_institucional: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Teléfono</div>
                <input value={editForm.telefono} onChange={(e) => setEditForm((p) => ({ ...p, telefono: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Código cargo</div>
                <input
                  value={editForm.codigo_cargo_id}
                  onChange={(e) => setEditForm((p) => ({ ...p, codigo_cargo_id: e.target.value.replace(/[^\d]/g, "") }))}
                  style={styles.input}
                />
              </div>

              <div>
                <div style={styles.label}>Código unidad</div>
                <input
                  value={editForm.codigo_unidad_id}
                  onChange={(e) => setEditForm((p) => ({ ...p, codigo_unidad_id: e.target.value.replace(/[^\d]/g, "") }))}
                  style={styles.input}
                />
              </div>

              <div>
                <div style={styles.label}>Fecha ingreso</div>
                <input type="date" value={editForm.fecha_ingreso || ""} onChange={(e) => setEditForm((p) => ({ ...p, fecha_ingreso: e.target.value }))} style={styles.input} />
              </div>

              <div>
                <div style={styles.label}>Fecha salida</div>
                <input type="date" value={editForm.fecha_salida || ""} onChange={(e) => setEditForm((p) => ({ ...p, fecha_salida: e.target.value }))} style={styles.input} />
              </div>

              <div style={{ display: "flex", alignItems: "flex-end" }}>
                <label style={styles.checkRow}>
                  <input type="checkbox" checked={Boolean(editForm.activo)} onChange={(e) => setEditForm((p) => ({ ...p, activo: e.target.checked }))} />
                  <span style={{ fontWeight: 900 }}>Activo</span>
                </label>
              </div>
            </div>

            <div style={styles.modalFooter}>
              <button style={styles.secondaryBtn} onClick={() => setOpenEdit(false)} disabled={editSaving}>
                Cancelar
              </button>
              <button style={styles.primaryBtn} onClick={saveEdit} disabled={editSaving}>
                {editSaving ? "Guardando…" : "Guardar cambios"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* =========================
   Subcomponentes y helpers
   ========================= */

function EquipoCard({ asignacion, isActual }) {
  const eq = asignacion?.equipo || null;

  const estado =
    eq?.estado?.descripcion ||
    eq?.codigo_estado?.descripcion ||
    eq?.estado ||
    null;

  const sede =
    eq?.ubicacion?.nombre_sede ||
    eq?.id_ubicacion?.nombre_sede ||
    null;

  const tipo =
    eq?.tipo_equipo?.descripcion ||
    eq?.codigo_tipo?.descripcion ||
    null;

  const marca =
    eq?.marca?.descripcion ||
    eq?.codigo_marca?.descripcion ||
    null;

  return (
    <div style={styles.equipoCard}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
        <div>
          <div style={{ fontWeight: 1000, color: "#0b1b3a" }}>
            {eq?.numero_inventario || "—"} · {eq?.modelo || "Sin modelo"}
          </div>
          <div style={{ fontSize: 12, color: "#6b7280" }}>
            Serie: {eq?.numero_serie || "—"}
            {estado ? ` · Estado: ${estado}` : ""}
          </div>

          {(sede || tipo || marca) ? (
            <div style={{ fontSize: 12, color: "#6b7280", marginTop: 4 }}>
              {sede ? `Sede: ${sede}` : null}
              {sede && (tipo || marca) ? " · " : null}
              {tipo ? `Tipo: ${tipo}` : null}
              {(tipo && marca) ? " · " : null}
              {marca ? `Marca: ${marca}` : null}
            </div>
          ) : null}
        </div>

        {isActual ? <span style={styles.pillOk}>Asignado</span> : <span style={styles.pillNeutral}>Histórico</span>}
      </div>

      <div style={{ marginTop: 8, fontSize: 12, color: "#6b7280" }}>
        Asignado: <b>{formatDate(asignacion?.fecha_asignacion)}</b>
        {" · "}
        Devolución: <b>{asignacion?.fecha_devolucion ? formatDate(asignacion?.fecha_devolucion) : "—"}</b>
      </div>

      {asignacion?.motivo_asignacion ? (
        <div style={{ marginTop: 8, fontSize: 13, color: "#111827", fontWeight: 800 }}>
          {asignacion.motivo_asignacion}
        </div>
      ) : null}
    </div>
  );
}

function getEstadoAsignacionLabel(a) {
  // si backend trae estado_asignacion (texto), úsalo
  const est = (a?.estado_asignacion || "").toString().trim();
  if (est) return est;

  // fallback: activo o fecha_devolucion
  if (a?.activo === true) return "Activa";
  if (a?.fecha_devolucion) return "Finalizada";
  return "—";
}

function KV({ label, value }) {
  return (
    <div style={styles.kv}>
      <div style={styles.kvLabel}>{label}</div>
      <div style={styles.kvValue}>{value ?? "—"}</div>
    </div>
  );
}

function formatDate(v) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

const styles = {
  headerRow: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, marginBottom: 14 },
  title: { margin: 0, fontSize: 34, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 6, color: "#6b7280", fontSize: 14 },
  headerActions: { display: "flex", gap: 10, alignItems: "center" },

  primaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #0b5cff", background: "#0b5cff", color: "#fff", fontWeight: 900, cursor: "pointer" },
  secondaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" },
  smallBtn: { height: 34, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" },

  error: { background: "#fff2f2", border: "1px solid #ffd1d1", color: "#b42318", padding: 10, borderRadius: 12, fontSize: 13, marginBottom: 12 },

  filtersCard: { background: "#fff", border: "1px solid #e9e9ee", borderRadius: 16, padding: 14, boxShadow: "0 10px 24px rgba(0,0,0,0.04)", marginBottom: 12 },
  filtersGrid: { display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 12, alignItems: "start" },

  label: { fontSize: 12, fontWeight: 1000, color: "#667085", marginBottom: 6 },
  help: { fontSize: 12, color: "#6b7280", marginTop: 6 },

  input: { width: "100%", height: 40, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", outline: "none", fontWeight: 800, color: "#111827" },

  checkRow: { display: "flex", gap: 10, alignItems: "center", paddingTop: 8 },

  card: { background: "#fff", border: "1px solid #e9e9ee", borderRadius: 16, overflow: "hidden", boxShadow: "0 10px 24px rgba(0,0,0,0.04)" },
  cardHeader: { padding: "14px 16px", borderBottom: "1px solid #eef2f7", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, background: "#fafafa" },
  cardTitle: { fontSize: 14, fontWeight: 1000, color: "#0b1b3a" },
  cardSub: { marginTop: 2, fontSize: 12, color: "#6b7280" },

  empty: { padding: 12, border: "1px dashed #e5e7eb", borderRadius: 12, color: "#6b7280", fontSize: 13, background: "#fff" },

  tableWrap: { overflowX: "auto" },
  table: { width: "100%", borderCollapse: "separate", borderSpacing: 0 },
  th: { textAlign: "left", fontSize: 12, color: "#667085", fontWeight: 1000, padding: "10px 10px", borderBottom: "1px solid #eef2f7", background: "#fafafa", position: "sticky", top: 0 },
  thRight: { textAlign: "right", fontSize: 12, color: "#667085", fontWeight: 1000, padding: "10px 10px", borderBottom: "1px solid #eef2f7", background: "#fafafa", position: "sticky", top: 0 },

  td: { padding: "12px 10px", borderBottom: "1px solid #f2f4f7", fontWeight: 800, color: "#111827", verticalAlign: "top" },
  tdRight: { padding: "12px 10px", borderBottom: "1px solid #f2f4f7", fontWeight: 800, color: "#111827", verticalAlign: "top", textAlign: "right", whiteSpace: "nowrap" },
  tdMono: { padding: "12px 10px", borderBottom: "1px solid #f2f4f7", fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace", fontWeight: 900, color: "#0b1b3a", verticalAlign: "top" },

  pillOk: { display: "inline-flex", alignItems: "center", padding: "6px 10px", borderRadius: 999, fontSize: 12, fontWeight: 900, border: "1px solid #bbf7d0", background: "#f0fdf4", color: "#166534", whiteSpace: "nowrap" },
  pillBad: { display: "inline-flex", alignItems: "center", padding: "6px 10px", borderRadius: 999, fontSize: 12, fontWeight: 900, border: "1px solid #fecaca", background: "#fff1f2", color: "#9f1239", whiteSpace: "nowrap" },
  pillNeutral: { display: "inline-flex", alignItems: "center", padding: "6px 10px", borderRadius: 999, fontSize: 12, fontWeight: 900, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", whiteSpace: "nowrap" },

  pagePill: { height: 34, display: "inline-flex", alignItems: "center", padding: "0 12px", borderRadius: 999, border: "1px solid #e5e7eb", background: "#fff", fontWeight: 900, color: "#111827" },

  modalOverlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.35)", display: "grid", placeItems: "center", padding: 16, zIndex: 50 },
  modal: { width: "min(920px, 100%)", background: "#fff", borderRadius: 16, border: "1px solid #e9e9ee", boxShadow: "0 24px 80px rgba(0,0,0,0.25)", overflow: "hidden" },
  modalHeader: { padding: "14px 16px", borderBottom: "1px solid #eef2f7", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, background: "#fafafa" },
  modalTitle: { fontSize: 16, fontWeight: 1000, color: "#0b1b3a" },
  modalSub: { marginTop: 2, fontSize: 12, color: "#6b7280" },
  iconBtn: { height: 34, width: 34, borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", fontWeight: 1000, cursor: "pointer" },

  formGrid: { padding: 16, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 },
  modalFooter: { padding: 16, borderTop: "1px solid #eef2f7", display: "flex", justifyContent: "flex-end", gap: 10, background: "#fff" },

  kvGrid: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 },
  kv: { border: "1px solid #eef2f7", background: "#fff", borderRadius: 12, padding: 10 },
  kvLabel: { fontSize: 12, color: "#667085", fontWeight: 1000 },
  kvValue: { marginTop: 4, fontWeight: 900, color: "#111827" },

  section: { border: "1px solid #eef2f7", borderRadius: 12, padding: 12, background: "#fff" },
  sectionTitle: { fontSize: 12, fontWeight: 1000, color: "#667085", marginBottom: 6 },

  equipoCard: { border: "1px solid #eef2f7", borderRadius: 12, padding: 12, background: "#fafafa" },

  histList: { display: "grid", gap: 8 },
  histItem: { border: "1px solid #f2f4f7", borderRadius: 12, padding: 10, background: "#fafafa" },
  histItemActive: { border: "1px solid #bbf7d0", borderRadius: 12, padding: 10, background: "#f0fdf4" },
};