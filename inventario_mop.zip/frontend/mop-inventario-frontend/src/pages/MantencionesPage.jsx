import { useEffect, useMemo, useState } from "react";
import { api } from "../api/api";

export default function MantencionesPage() {
  // ---- data ----
  const [rows, setRows] = useState([]);
  const [count, setCount] = useState(0);

  const [tipos, setTipos] = useState([]);
  const [equipos, setEquipos] = useState([]);
  const [estadosMant, setEstadosMant] = useState([]); // catálogo estados mantenimiento

  // ---- ui ----
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // ---- filtros/paginación ----
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const [qEquipo, setQEquipo] = useState("");
  const [equipoSel, setEquipoSel] = useState(null);
  const [tipoSel, setTipoSel] = useState("");
  const [soloRecientes, setSoloRecientes] = useState(false);

  // ---- modal: nueva ----
  const [openNew, setOpenNew] = useState(false);
  const [form, setForm] = useState({
    id_equipo_id: "",
    codigo_tipo_mantenimiento_id: "",
    fecha_solicitud: todayISO(),
    problema_reportado: "",
    observaciones: "",
  });
  const [saving, setSaving] = useState(false);
  const [formErr, setFormErr] = useState("");

  // ---- modal: ver / editar ----
  const [openView, setOpenView] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [active, setActive] = useState(null);

  const [historialEquipo, setHistorialEquipo] = useState([]);
  const [histLoading, setHistLoading] = useState(false);

  const [editSaving, setEditSaving] = useState(false);
  const [editErr, setEditErr] = useState("");
  const [editForm, setEditForm] = useState({
    codigo_estado_mantenimiento_id: "",
    diagnostico_tecnico: "",
    solucion_aplicada: "",
    fecha_ingreso_taller: "",
    fecha_salida_taller: "",
    fecha_entrega: "",
    observaciones: "",
  });

  // ✅ FIX: esta función DEBE vivir dentro del componente para usar setEditForm
  function applyQuickStatus(kind) {
    const t = todayISO();

    setEditForm((p) => {
      if (kind === "taller") {
        return {
          ...p,
          fecha_ingreso_taller: p.fecha_ingreso_taller || t,
        };
      }
      if (kind === "terminado") {
        return {
          ...p,
          fecha_ingreso_taller: p.fecha_ingreso_taller || t,
          fecha_salida_taller: p.fecha_salida_taller || t,
        };
      }
      if (kind === "entregado") {
        return {
          ...p,
          fecha_ingreso_taller: p.fecha_ingreso_taller || t,
          fecha_salida_taller: p.fecha_salida_taller || t,
          fecha_entrega: p.fecha_entrega || t,
        };
      }
      if (kind === "reset") {
        return {
          ...p,
          fecha_ingreso_taller: "",
          fecha_salida_taller: "",
          fecha_entrega: "",
          codigo_estado_mantenimiento_id: "",
        };
      }
      return p;
    });
  }

  async function loadCatalogos() {
    const res = await api.get("/catalogos/tipos-mantenimiento/");
    setTipos(res.data?.results ?? res.data ?? []);

    try {
      const res2 = await api.get("/catalogos/estados-mantenimiento/");
      setEstadosMant(res2.data?.results ?? res2.data ?? []);
    } catch {
      setEstadosMant([]);
    }
  }

  async function searchEquipos(term) {
    if (!term || term.trim().length < 2) {
      setEquipos([]);
      return;
    }
    const res = await api.get("/equipos/", {
      params: { search: term.trim(), ordering: "-id_equipo", page: 1 },
    });
    const list = res.data?.results ?? res.data ?? [];
    setEquipos(list.slice(0, 8));
  }

  async function loadMantenimientos(p = page) {
    setLoading(true);
    setErr("");
    try {
      const params = { ordering: "-id_mantenimiento", page: p };
      if (equipoSel?.id_equipo) params.id_equipo = equipoSel.id_equipo;

      const res = await api.get("/mantenimientos/", { params });
      const list = res.data?.results ?? res.data ?? [];
      const total = res.data?.count ?? list.length;

      let viewList = list;

      if (tipoSel) {
        viewList = viewList.filter(
          (x) =>
            String(x?.tipo_mantenimiento?.codigo_tipo_mantenimiento ?? "") ===
            String(tipoSel)
        );
      }

      if (soloRecientes) {
        const limit = new Date();
        limit.setDate(limit.getDate() - 30);
        viewList = viewList.filter((x) => {
          const d = new Date(x?.fecha_solicitud || x?.fecha_creacion || "");
          return !Number.isNaN(d.getTime()) && d >= limit;
        });
      }

      setRows(viewList);
      setCount(total);
    } catch (e) {
      setErr(e?.response?.data?.detail || e?.message || "Error cargando mantenciones");
    } finally {
      setLoading(false);
    }
  }

  // init
  useEffect(() => {
    (async () => {
      try {
        await loadCatalogos();
      } finally {
        loadMantenimientos(1);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // cambios filtros -> vuelve a page 1
  useEffect(() => {
    setPage(1);
    loadMantenimientos(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [equipoSel, tipoSel, soloRecientes]);

  const totalPages = useMemo(() => {
    return Math.max(Math.ceil((count || 0) / pageSize), 1);
  }, [count]);

  function openNewModal() {
    setFormErr("");
    setForm({
      id_equipo_id: equipoSel?.id_equipo ? String(equipoSel.id_equipo) : "",
      codigo_tipo_mantenimiento_id: "",
      fecha_solicitud: todayISO(),
      problema_reportado: "",
      observaciones: "",
    });
    setOpenNew(true);
  }

  async function createMantenimiento() {
    setSaving(true);
    setFormErr("");
    try {
      if (!form.id_equipo_id) return setFormErr("Selecciona un equipo.");
      if (!form.codigo_tipo_mantenimiento_id) return setFormErr("Selecciona un tipo de mantención.");
      if (!form.fecha_solicitud) return setFormErr("Ingresa fecha de solicitud.");

      const payload = {
        id_equipo_id: Number(form.id_equipo_id),
        codigo_tipo_mantenimiento_id: Number(form.codigo_tipo_mantenimiento_id),
        fecha_solicitud: form.fecha_solicitud,
        problema_reportado: form.problema_reportado || "",
        observaciones: form.observaciones || "",
      };

      await api.post("/mantenimientos/", payload);

      setOpenNew(false);
      setPage(1);
      await loadMantenimientos(1);
    } catch (e) {
      const data = e?.response?.data;
      if (data && typeof data === "object") {
        const firstKey = Object.keys(data)[0];
        const msg = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
        setFormErr(msg || "No se pudo crear la mantención.");
      } else {
        setFormErr(e?.message || "No se pudo crear la mantención.");
      }
    } finally {
      setSaving(false);
    }
  }

  // ---- Estado robusto ----
  function resolveEstadoMant(m) {
    if (m?.estado_mantenimiento_display) return m.estado_mantenimiento_display;
    if (m?.estado_mantenimiento?.descripcion) return m.estado_mantenimiento.descripcion;

    const id = m?.codigo_estado_mantenimiento;
    if (id == null || id === "") return "Pendiente";

    const found =
      estadosMant.find(
        (x) => String(x?.codigo_estado_mantenimiento ?? x?.id ?? x?.codigo ?? "") === String(id)
      ) || null;

    return found?.descripcion || `Estado #${id}`;
  }

  function pillStyleByEstado(label) {
    const v = String(label || "").toLowerCase();
    if (v.includes("pend") || v.includes("abiert") || v.includes("nuevo")) {
      return { ...styles.pillSoft, borderColor: "#dbeafe", background: "#eef4ff", color: "#0b4edb" };
    }
    if (v.includes("taller") || v.includes("diagn") || v.includes("proceso") || v.includes("curso")) {
      return { ...styles.pillSoft, borderColor: "#fed7aa", background: "#fff7ed", color: "#9a3412" };
    }
    if (v.includes("termin") || v.includes("cerr") || v.includes("resuelt") || v.includes("final")) {
      return { ...styles.pillSoft, borderColor: "#bbf7d0", background: "#f0fdf4", color: "#166534" };
    }
    if (v.includes("rechaz") || v.includes("cancel") || v.includes("anulad")) {
      return { ...styles.pillSoft, borderColor: "#fecaca", background: "#fff1f2", color: "#9f1239" };
    }
    return styles.pillSoft;
  }

  // ---- Historial del EQUIPO asociado ----
  async function loadHistorialEquipo(m) {
    const idEquipo = m?.equipo?.id_equipo ?? null;
    if (!idEquipo) {
      setHistorialEquipo([]);
      return;
    }
    setHistLoading(true);
    try {
      const res = await api.get("/historial-estados/", {
        params: { id_equipo: idEquipo, ordering: "-id_historial_estado" },
      });
      setHistorialEquipo(res.data?.results ?? res.data ?? []);
    } catch {
      setHistorialEquipo([]);
    } finally {
      setHistLoading(false);
    }
  }

  async function openViewModal(m) {
    setActive(m);
    setOpenView(true);
    await loadHistorialEquipo(m);
  }

  function openEditModal(m) {
    setActive(m);
    setEditErr("");

    setEditForm({
      codigo_estado_mantenimiento_id:
        String(m?.codigo_estado_mantenimiento ?? m?.estado_mantenimiento?.codigo_estado_mantenimiento ?? "") || "",
      diagnostico_tecnico: m?.diagnostico_tecnico || "",
      solucion_aplicada: m?.solucion_aplicada || "",
      fecha_ingreso_taller: m?.fecha_ingreso_taller || "",
      fecha_salida_taller: m?.fecha_salida_taller || "",
      fecha_entrega: m?.fecha_entrega || "",
      observaciones: m?.observaciones || "",
    });

    setOpenEdit(true);
    loadHistorialEquipo(m);
  }

  // ✅ saveEdit correcto: NO manda estado si está vacío (para que el backend auto-calcule por fechas)
  async function saveEdit() {
    if (!active?.id_mantenimiento) return;

    setEditSaving(true);
    setEditErr("");
    try {
      const payload = {
        diagnostico_tecnico: editForm.diagnostico_tecnico || "",
        solucion_aplicada: editForm.solucion_aplicada || "",
        fecha_ingreso_taller: editForm.fecha_ingreso_taller || null,
        fecha_salida_taller: editForm.fecha_salida_taller || null,
        fecha_entrega: editForm.fecha_entrega || null,
        observaciones: editForm.observaciones || "",
      };

      if (editForm.codigo_estado_mantenimiento_id) {
        payload.codigo_estado_mantenimiento_id = Number(editForm.codigo_estado_mantenimiento_id);
      }

      await api.patch(`/mantenimientos/${active.id_mantenimiento}/`, payload);

      setOpenEdit(false);
      await loadMantenimientos(page);
    } catch (e) {
      const data = e?.response?.data;
      if (data && typeof data === "object") {
        const firstKey = Object.keys(data)[0];
        const msg = Array.isArray(data[firstKey]) ? data[firstKey][0] : String(data[firstKey]);
        setEditErr(msg || "No se pudo guardar.");
      } else {
        setEditErr(e?.message || "No se pudo guardar.");
      }
    } finally {
      setEditSaving(false);
    }
  }

  return (
    <div>
      {/* Header */}
      <div style={styles.headerRow}>
        <div>
          <h1 style={styles.title}>Mantenciones</h1>
          <div style={styles.sub}>Lista, filtra, revisa historial y edita mantenciones.</div>
        </div>

        <div style={styles.headerActions}>
          <button style={styles.secondaryBtn} onClick={() => loadMantenimientos(page)} disabled={loading}>
            {loading ? "Actualizando…" : "Actualizar"}
          </button>
          <button style={styles.primaryBtn} onClick={openNewModal}>
            + Nueva mantención
          </button>
        </div>
      </div>

      {err ? <div style={styles.error}>{err}</div> : null}

      {/* Filtros */}
      <div style={styles.filtersCard}>
        <div style={styles.filtersGrid}>
          {/* Buscar equipo */}
          <div>
            <div style={styles.label}>Equipo</div>
            <div style={{ display: "grid", gap: 8 }}>
              <input
                value={qEquipo}
                onChange={(e) => {
                  const v = e.target.value;
                  setQEquipo(v);
                  searchEquipos(v);
                }}
                placeholder="Buscar (inventario / serie / modelo)…"
                style={styles.input}
              />

              {equipos.length > 0 ? (
                <div style={styles.suggestBox}>
                  {equipos.map((eq) => (
                    <button
                      key={eq.id_equipo}
                      style={styles.suggestItem}
                      onClick={() => {
                        setEquipoSel(eq);
                        setEquipos([]);
                        setQEquipo(`${eq.numero_inventario || "—"} · ${eq.modelo || ""}`.trim());
                      }}
                      title="Seleccionar equipo"
                    >
                      <div style={{ fontWeight: 900, color: "#0b1b3a" }}>{eq.numero_inventario || "—"}</div>
                      <div style={{ fontSize: 12, color: "#6b7280" }}>
                        {eq.modelo || "Sin modelo"} · {eq.numero_serie || "Sin serie"}
                      </div>
                    </button>
                  ))}
                </div>
              ) : null}

              {equipoSel ? (
                <div style={styles.selectedPillRow}>
                  <div style={styles.selectedPill}>
                    ✅ {equipoSel.numero_inventario || "Equipo"}{" "}
                    <span style={{ color: "#6b7280", fontWeight: 800 }}>· {equipoSel.modelo || "Sin modelo"}</span>
                  </div>
                  <button style={styles.clearBtn} onClick={() => { setEquipoSel(null); setQEquipo(""); }}>
                    Quitar
                  </button>
                </div>
              ) : (
                <div style={styles.help}>Tip: escribe al menos 2 caracteres para buscar equipos.</div>
              )}
            </div>
          </div>

          {/* Tipo mantención */}
          <div>
            <div style={styles.label}>Tipo mantención</div>
            <select value={tipoSel} onChange={(e) => setTipoSel(e.target.value)} style={styles.input}>
              <option value="">(Todos)</option>
              {tipos.map((t) => (
                <option key={t.codigo_tipo_mantenimiento} value={String(t.codigo_tipo_mantenimiento)}>
                  {t.descripcion}
                </option>
              ))}
            </select>
            <div style={styles.help}>Filtro visual (no afecta el backend).</div>
          </div>

          {/* Recientes */}
          <div>
            <div style={styles.label}>Vista</div>
            <label style={styles.checkRow}>
              <input type="checkbox" checked={soloRecientes} onChange={(e) => setSoloRecientes(e.target.checked)} />
              <span style={{ fontWeight: 900 }}>Solo últimos 30 días</span>
            </label>
            <div style={styles.help}>Útil para ver lo importante del mes.</div>
          </div>
        </div>
      </div>

      {/* Tabla */}
      <div style={styles.card}>
        <div style={styles.cardHeader}>
          <div>
            <div style={styles.cardTitle}>Listado</div>
            <div style={styles.cardSub}>{loading ? "Cargando…" : `${count || 0} registros`}</div>
          </div>

          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button
              style={styles.smallBtn}
              onClick={() => {
                const p = Math.max(page - 1, 1);
                setPage(p);
                loadMantenimientos(p);
              }}
              disabled={loading || page <= 1}
            >
              ←
            </button>

            <div style={styles.pagePill}>
              Página <b>{page}</b> / {totalPages}
            </div>

            <button
              style={styles.smallBtn}
              onClick={() => {
                const p = Math.min(page + 1, totalPages);
                setPage(p);
                loadMantenimientos(p);
              }}
              disabled={loading || page >= totalPages}
            >
              →
            </button>
          </div>
        </div>

        <div style={{ padding: 14 }}>
          {!loading && rows.length === 0 ? (
            <div style={styles.empty}>No hay mantenciones para mostrar con estos filtros.</div>
          ) : (
            <div style={styles.tableWrap}>
              <table style={styles.table}>
                <thead>
                  <tr>
                    <th style={styles.th}>ID</th>
                    <th style={styles.th}>Equipo</th>
                    <th style={styles.th}>Tipo</th>
                    <th style={styles.th}>Solicitud</th>
                    <th style={styles.th}>Estado</th>
                    <th style={styles.th}>Problema</th>
                    <th style={styles.thRight}>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((m) => {
                    const estadoLabel = resolveEstadoMant(m);
                    return (
                      <tr key={m.id_mantenimiento}>
                        <td style={styles.tdMono}>{m.id_mantenimiento}</td>

                        <td style={styles.td}>
                          <div style={{ fontWeight: 1000, color: "#0b1b3a" }}>
                            {m?.equipo?.numero_inventario || "—"}
                          </div>
                          <div style={{ fontSize: 12, color: "#6b7280" }}>
                            {m?.equipo?.modelo || "Sin modelo"}
                          </div>
                        </td>

                        <td style={styles.td}>{m?.tipo_mantenimiento?.descripcion || "—"}</td>
                        <td style={styles.td}>{formatDate(m?.fecha_solicitud)}</td>

                        <td style={styles.td}>
                          <span style={pillStyleByEstado(estadoLabel)}>{estadoLabel}</span>
                        </td>

                        <td style={styles.td}>
                          <div style={styles.clamp2}>{m?.problema_reportado || "—"}</div>
                        </td>

                        <td style={styles.tdRight}>
                          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                            <button style={styles.smallBtn} onClick={() => openViewModal(m)}>
                              Ver
                            </button>
                            <button style={styles.smallBtn} onClick={() => openEditModal(m)}>
                              Editar
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Nueva mantención */}
      {openNew ? (
        <div style={styles.modalOverlay} onMouseDown={() => setOpenNew(false)}>
          <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <div>
                <div style={styles.modalTitle}>Nueva mantención</div>
                <div style={styles.modalSub}>Crea una solicitud y queda registrada en el sistema.</div>
              </div>
              <button style={styles.iconBtn} onClick={() => setOpenNew(false)} title="Cerrar">
                ✕
              </button>
            </div>

            {formErr ? <div style={styles.error}>{formErr}</div> : null}

            <div style={styles.formGrid}>
              <div style={{ gridColumn: "1 / -1" }}>
                <div style={styles.label}>Equipo *</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 10 }}>
                  <input
                    value={form.id_equipo_id ? `ID: ${form.id_equipo_id}` : ""}
                    placeholder="Selecciona equipo desde el filtro o escribe un ID…"
                    onChange={(e) => setForm((p) => ({ ...p, id_equipo_id: e.target.value.replace(/[^\d]/g, "") }))}
                    style={styles.input}
                  />
                  <button
                    style={styles.secondaryBtn}
                    onClick={() => {
                      if (equipoSel?.id_equipo) setForm((p) => ({ ...p, id_equipo_id: String(equipoSel.id_equipo) }));
                    }}
                  >
                    Usar seleccionado
                  </button>
                </div>
                <div style={styles.help}>Recomendado: elige un equipo arriba y presiona “Usar seleccionado”.</div>
              </div>

              <div>
                <div style={styles.label}>Tipo mantención *</div>
                <select
                  value={form.codigo_tipo_mantenimiento_id}
                  onChange={(e) => setForm((p) => ({ ...p, codigo_tipo_mantenimiento_id: e.target.value }))}
                  style={styles.input}
                >
                  <option value="">Selecciona…</option>
                  {tipos.map((t) => (
                    <option key={t.codigo_tipo_mantenimiento} value={String(t.codigo_tipo_mantenimiento)}>
                      {t.descripcion}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div style={styles.label}>Fecha solicitud *</div>
                <input
                  type="date"
                  value={form.fecha_solicitud}
                  onChange={(e) => setForm((p) => ({ ...p, fecha_solicitud: e.target.value }))}
                  style={styles.input}
                />
              </div>

              <div style={{ gridColumn: "1 / -1" }}>
                <div style={styles.label}>Problema reportado</div>
                <textarea
                  value={form.problema_reportado}
                  onChange={(e) => setForm((p) => ({ ...p, problema_reportado: e.target.value }))}
                  rows={3}
                  style={styles.textarea}
                />
              </div>

              <div style={{ gridColumn: "1 / -1" }}>
                <div style={styles.label}>Observaciones</div>
                <textarea
                  value={form.observaciones}
                  onChange={(e) => setForm((p) => ({ ...p, observaciones: e.target.value }))}
                  rows={3}
                  style={styles.textarea}
                />
              </div>
            </div>

            <div style={styles.modalFooter}>
              <button style={styles.secondaryBtn} onClick={() => setOpenNew(false)} disabled={saving}>
                Cancelar
              </button>
              <button style={styles.primaryBtn} onClick={createMantenimiento} disabled={saving}>
                {saving ? "Guardando…" : "Crear mantención"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Modal: Ver */}
      {openView && active ? (
        <div style={styles.modalOverlay} onMouseDown={() => setOpenView(false)}>
          <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <div>
                <div style={styles.modalTitle}>Mantención #{active.id_mantenimiento}</div>
                <div style={styles.modalSub}>
                  {active?.equipo?.numero_inventario || "Equipo"} · {active?.equipo?.modelo || "Sin modelo"}
                </div>
              </div>
              <button style={styles.iconBtn} onClick={() => setOpenView(false)} title="Cerrar">
                ✕
              </button>
            </div>

            <div style={{ padding: 16, display: "grid", gap: 12 }}>
              <div style={styles.kvGrid}>
                <KV label="Tipo" value={active?.tipo_mantenimiento?.descripcion || "—"} />
                <KV label="Estado" value={resolveEstadoMant(active)} />
                <KV label="Solicitud" value={formatDate(active?.fecha_solicitud)} />
                <KV label="Ingreso taller" value={formatDate(active?.fecha_ingreso_taller)} />
                <KV label="Salida taller" value={formatDate(active?.fecha_salida_taller)} />
                <KV label="Entrega" value={formatDate(active?.fecha_entrega)} />
              </div>

              <div style={styles.section}>
                <div style={styles.sectionTitle}>Problema</div>
                <div style={styles.sectionBody}>{active?.problema_reportado || "—"}</div>
              </div>

              <div style={styles.section}>
                <div style={styles.sectionTitle}>Diagnóstico</div>
                <div style={styles.sectionBody}>{active?.diagnostico_tecnico || "—"}</div>
              </div>

              <div style={styles.section}>
                <div style={styles.sectionTitle}>Solución</div>
                <div style={styles.sectionBody}>{active?.solucion_aplicada || "—"}</div>
              </div>

              <div style={styles.section}>
                <div style={styles.sectionTitle}>Historial del equipo</div>
                {histLoading ? (
                  <div style={styles.help}>Cargando historial…</div>
                ) : historialEquipo.length === 0 ? (
                  <div style={styles.help}>No hay historial de estados para este equipo.</div>
                ) : (
                  <div style={styles.histList}>
                    {historialEquipo.slice(0, 8).map((h) => (
                      <div key={h.id_historial_estado} style={styles.histItem}>
                        <div style={{ fontWeight: 1000 }}>
                          {h?.codigo_estado_anterior?.descripcion || "—"} → {h?.codigo_estado_nuevo?.descripcion || "—"}
                        </div>
                        <div style={{ fontSize: 12, color: "#6b7280" }}>
                          {formatDateTime(h?.fecha_cambio)} · {h?.motivo_detallado || "—"}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div style={styles.modalFooter}>
              <button style={styles.secondaryBtn} onClick={() => setOpenView(false)}>
                Cerrar
              </button>
              <button
                style={styles.primaryBtn}
                onClick={() => {
                  setOpenView(false);
                  openEditModal(active);
                }}
              >
                Editar
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Modal: Editar */}
      {openEdit && active ? (
        <div style={styles.modalOverlay} onMouseDown={() => setOpenEdit(false)}>
          <div style={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <div>
                <div style={styles.modalTitle}>Editar mantención #{active.id_mantenimiento}</div>
                <div style={styles.modalSub}>
                  {active?.equipo?.numero_inventario || "Equipo"} · {active?.equipo?.modelo || "Sin modelo"}
                </div>
              </div>
              <button style={styles.iconBtn} onClick={() => setOpenEdit(false)} title="Cerrar">
                ✕
              </button>
            </div>

            {editErr ? <div style={styles.error}>{editErr}</div> : null}

            {/* ✅ Bloque PRO: acciones rápidas */}
            <div style={{ padding: "0 16px 12px 16px" }}>
              <div style={styles.label}>Acciones rápidas</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button style={styles.smallBtn} type="button" onClick={() => applyQuickStatus("taller")}>
                  🛠️ Marcar “En taller”
                </button>
                <button style={styles.smallBtn} type="button" onClick={() => applyQuickStatus("terminado")}>
                  ✅ Marcar “Terminado”
                </button>
                <button style={styles.smallBtn} type="button" onClick={() => applyQuickStatus("entregado")}>
                  📦 Marcar “Entregado”
                </button>
                <button style={styles.smallBtn} type="button" onClick={() => applyQuickStatus("reset")}>
                  ↩️ Reset fechas/estado
                </button>
              </div>
              <div style={styles.help}>
                Tip: si dejas “Estado” vacío y solo pones fechas, el backend lo calcula automático.
              </div>
            </div>

            <div style={styles.formGrid}>
              <div>
                <div style={styles.label}>Estado</div>
                <select
                  value={editForm.codigo_estado_mantenimiento_id}
                  onChange={(e) => setEditForm((p) => ({ ...p, codigo_estado_mantenimiento_id: e.target.value }))}
                  style={styles.input}
                >
                  <option value="">(Sin estado)</option>
                  {estadosMant.map((s) => (
                    <option key={s.codigo_estado_mantenimiento} value={String(s.codigo_estado_mantenimiento)}>
                      {s.descripcion}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div style={styles.label}>Ingreso taller</div>
                <input
                  type="date"
                  value={editForm.fecha_ingreso_taller || ""}
                  onChange={(e) => setEditForm((p) => ({ ...p, fecha_ingreso_taller: e.target.value }))}
                  style={styles.input}
                />
              </div>

              <div>
                <div style={styles.label}>Salida taller</div>
                <input
                  type="date"
                  value={editForm.fecha_salida_taller || ""}
                  onChange={(e) => setEditForm((p) => ({ ...p, fecha_salida_taller: e.target.value }))}
                  style={styles.input}
                />
              </div>

              <div>
                <div style={styles.label}>Entrega</div>
                <input
                  type="date"
                  value={editForm.fecha_entrega || ""}
                  onChange={(e) => setEditForm((p) => ({ ...p, fecha_entrega: e.target.value }))}
                  style={styles.input}
                />
              </div>

              <div style={{ gridColumn: "1 / -1" }}>
                <div style={styles.label}>Diagnóstico</div>
                <textarea
                  value={editForm.diagnostico_tecnico}
                  onChange={(e) => setEditForm((p) => ({ ...p, diagnostico_tecnico: e.target.value }))}
                  rows={3}
                  style={styles.textarea}
                />
              </div>

              <div style={{ gridColumn: "1 / -1" }}>
                <div style={styles.label}>Solución aplicada</div>
                <textarea
                  value={editForm.solucion_aplicada}
                  onChange={(e) => setEditForm((p) => ({ ...p, solucion_aplicada: e.target.value }))}
                  rows={3}
                  style={styles.textarea}
                />
              </div>

              <div style={{ gridColumn: "1 / -1" }}>
                <div style={styles.label}>Observaciones</div>
                <textarea
                  value={editForm.observaciones}
                  onChange={(e) => setEditForm((p) => ({ ...p, observaciones: e.target.value }))}
                  rows={3}
                  style={styles.textarea}
                />
              </div>
            </div>

            <div style={styles.modalFooter}>
              <button style={styles.secondaryBtn} onClick={() => setOpenEdit(false)} disabled={editSaving}>
                Cancelar
              </button>
              <button style={styles.primaryBtn} onClick={saveEdit} disabled={editSaving}>
                {editSaving ? "Guardando…" : "Guardar cambios"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function KV({ label, value }) {
  return (
    <div style={styles.kv}>
      <div style={styles.kvLabel}>{label}</div>
      <div style={styles.kvValue}>{value ?? "—"}</div>
    </div>
  );
}

function todayISO() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function formatDate(v) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

function formatDateTime(v) {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${dd}-${mm}-${yyyy} ${hh}:${mi}`;
}

const styles = {
  headerRow: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, marginBottom: 14 },
  title: { margin: 0, fontSize: 34, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 6, color: "#6b7280", fontSize: 14 },
  headerActions: { display: "flex", gap: 10, alignItems: "center" },

  primaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #0b5cff", background: "#0b5cff", color: "#fff", fontWeight: 900, cursor: "pointer" },
  secondaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" },
  smallBtn: { height: 34, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" },

  error: { background: "#fff2f2", border: "1px solid #ffd1d1", color: "#b42318", padding: 10, borderRadius: 12, fontSize: 13, marginBottom: 12 },

  filtersCard: { background: "#fff", border: "1px solid #e9e9ee", borderRadius: 16, padding: 14, boxShadow: "0 10px 24px rgba(0,0,0,0.04)", marginBottom: 12 },
  filtersGrid: { display: "grid", gridTemplateColumns: "1.4fr 0.8fr 0.8fr", gap: 12, alignItems: "start" },

  label: { fontSize: 12, fontWeight: 1000, color: "#667085", marginBottom: 6 },
  help: { fontSize: 12, color: "#6b7280", marginTop: 6 },

  input: { width: "100%", height: 40, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", outline: "none", fontWeight: 800, color: "#111827" },
  textarea: { width: "100%", padding: 12, borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", outline: "none", fontWeight: 700, color: "#111827", resize: "vertical" },

  suggestBox: { border: "1px solid #eef2f7", borderRadius: 12, overflow: "hidden", background: "#fff", boxShadow: "0 12px 30px rgba(0,0,0,0.06)" },
  suggestItem: { width: "100%", padding: 10, border: 0, borderBottom: "1px solid #f2f4f7", background: "#fff", cursor: "pointer", textAlign: "left" },

  selectedPillRow: { display: "flex", gap: 10, alignItems: "center" },
  selectedPill: { flex: 1, borderRadius: 999, border: "1px solid #dbeafe", background: "#eef4ff", padding: "8px 12px", fontWeight: 900, color: "#0b4edb" },
  clearBtn: { height: 34, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", fontWeight: 900, cursor: "pointer" },

  checkRow: { display: "flex", gap: 10, alignItems: "center", paddingTop: 8 },

  card: { background: "#fff", border: "1px solid #e9e9ee", borderRadius: 16, overflow: "hidden", boxShadow: "0 10px 24px rgba(0,0,0,0.04)" },
  cardHeader: { padding: "14px 16px", borderBottom: "1px solid #eef2f7", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, background: "#fafafa" },
  cardTitle: { fontSize: 14, fontWeight: 1000, color: "#0b1b3a" },
  cardSub: { marginTop: 2, fontSize: 12, color: "#6b7280" },

  empty: { padding: 12, border: "1px dashed #e5e7eb", borderRadius: 12, color: "#6b7280", fontSize: 13, background: "#fff" },

  tableWrap: { overflowX: "auto" },
  table: { width: "100%", borderCollapse: "separate", borderSpacing: 0 },
  th: { textAlign: "left", fontSize: 12, color: "#667085", fontWeight: 1000, padding: "10px 10px", borderBottom: "1px solid #eef2f7", background: "#fafafa", position: "sticky", top: 0 },
  thRight: { textAlign: "right", fontSize: 12, color: "#667085", fontWeight: 1000, padding: "10px 10px", borderBottom: "1px solid #eef2f7", background: "#fafafa", position: "sticky", top: 0 },

  td: { padding: "12px 10px", borderBottom: "1px solid #f2f4f7", fontWeight: 800, color: "#111827", verticalAlign: "top" },
  tdRight: { padding: "12px 10px", borderBottom: "1px solid #f2f4f7", fontWeight: 800, color: "#111827", verticalAlign: "top", textAlign: "right", whiteSpace: "nowrap" },
  tdMono: { padding: "12px 10px", borderBottom: "1px solid #f2f4f7", fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace", fontWeight: 900, color: "#0b1b3a", verticalAlign: "top" },

  clamp2: { display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" },

  pillSoft: { display: "inline-flex", alignItems: "center", padding: "6px 10px", borderRadius: 999, fontSize: 12, fontWeight: 900, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", whiteSpace: "nowrap" },

  pagePill: { height: 34, display: "inline-flex", alignItems: "center", padding: "0 12px", borderRadius: 999, border: "1px solid #e5e7eb", background: "#fff", fontWeight: 900, color: "#111827" },

  modalOverlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.35)", display: "grid", placeItems: "center", padding: 16, zIndex: 50 },
  modal: { width: "min(920px, 100%)", background: "#fff", borderRadius: 16, border: "1px solid #e9e9ee", boxShadow: "0 24px 80px rgba(0,0,0,0.25)", overflow: "hidden" },
  modalHeader: { padding: "14px 16px", borderBottom: "1px solid #eef2f7", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, background: "#fafafa" },
  modalTitle: { fontSize: 16, fontWeight: 1000, color: "#0b1b3a" },
  modalSub: { marginTop: 2, fontSize: 12, color: "#6b7280" },
  iconBtn: { height: 34, width: 34, borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", fontWeight: 1000, cursor: "pointer" },

  formGrid: { padding: 16, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 },
  modalFooter: { padding: 16, borderTop: "1px solid #eef2f7", display: "flex", justifyContent: "flex-end", gap: 10, background: "#fff" },

  kvGrid: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 },
  kv: { border: "1px solid #eef2f7", background: "#fff", borderRadius: 12, padding: 10 },
  kvLabel: { fontSize: 12, color: "#667085", fontWeight: 1000 },
  kvValue: { marginTop: 4, fontWeight: 900, color: "#111827" },

  section: { border: "1px solid #eef2f7", borderRadius: 12, padding: 12, background: "#fff" },
  sectionTitle: { fontSize: 12, fontWeight: 1000, color: "#667085", marginBottom: 6 },
  sectionBody: { fontWeight: 800, color: "#111827", whiteSpace: "pre-wrap" },

  histList: { display: "grid", gap: 8 },
  histItem: { border: "1px solid #f2f4f7", borderRadius: 12, padding: 10, background: "#fafafa" },
};
