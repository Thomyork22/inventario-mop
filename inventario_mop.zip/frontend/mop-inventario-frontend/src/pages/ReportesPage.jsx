import { useEffect, useMemo, useState } from "react";
import { api } from "../api/api";

export default function ReportesPage() {
  // --- catálogos para filtros ---
  const [ubicaciones, setUbicaciones] = useState([]);
  const [estadosEquipo, setEstadosEquipo] = useState([]);

  // --- filtros inventario ---
  const [invActivo, setInvActivo] = useState(""); // "" | "true" | "false"
  const [invUbicacion, setInvUbicacion] = useState(""); // id_ubicacion
  const [invEstado, setInvEstado] = useState(""); // codigo_estado

  // --- filtros asignaciones ---
  const [asigSoloActivas, setAsigSoloActivas] = useState(true);

  // --- filtros garantías ---
  const [garTipo, setGarTipo] = useState("pv"); // pv | vencidas
  const [garDias, setGarDias] = useState(30);

  // --- ui ---
  const [loadingCats, setLoadingCats] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const [err, setErr] = useState("");

  const invParams = useMemo(() => {
    const p = {};
    if (invActivo !== "") p.activo = invActivo;
    if (invUbicacion) p.id_ubicacion = invUbicacion;
    if (invEstado) p.codigo_estado = invEstado;
    return p;
  }, [invActivo, invUbicacion, invEstado]);

  const asigParams = useMemo(() => {
    const p = {};
    if (asigSoloActivas) p.solo_activas = "true";
    return p;
  }, [asigSoloActivas]);

  const garParams = useMemo(() => {
    const p = { tipo: garTipo, dias: String(garDias || 30) };
    return p;
  }, [garTipo, garDias]);

  async function loadCatalogos() {
    setLoadingCats(true);
    setErr("");
    try {
      const [u, e] = await Promise.all([
        api.get("/catalogos/ubicaciones/", { params: { page_size: 9999 } }),
        api.get("/catalogos/estados-equipo/", { params: { page_size: 9999 } }),
      ]);

      const uList = u.data?.results ?? u.data ?? [];
      const eList = e.data?.results ?? e.data ?? [];

      setUbicaciones(Array.isArray(uList) ? uList : []);
      setEstadosEquipo(Array.isArray(eList) ? eList : []);
    } catch (e) {
      setErr(e?.response?.data?.detail || e?.message || "No se pudieron cargar los catálogos.");
    } finally {
      setLoadingCats(false);
    }
  }

  useEffect(() => {
    loadCatalogos();
  }, []);

  async function downloadFile({ url, filename, params }) {
    setDownloading(true);
    setErr("");
    try {
      const res = await api.get(url, {
        params,
        responseType: "blob",
      });

      const blob = new Blob([res.data]);
      const href = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = href;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();

      window.URL.revokeObjectURL(href);
    } catch (e) {
      setErr(e?.response?.data?.detail || e?.message || "No se pudo descargar el reporte.");
    } finally {
      setDownloading(false);
    }
  }

  return (
    <div>
      {/* Header */}
      <div style={styles.headerRow}>
        <div>
          <h1 style={styles.title}>Reportes</h1>
          <div style={styles.sub}>
            Descarga reportes en CSV o Excel (XLSX) con filtros básicos.
          </div>
        </div>

        <div style={styles.headerActions}>
          <button style={styles.secondaryBtn} onClick={loadCatalogos} disabled={loadingCats || downloading}>
            {loadingCats ? "Cargando…" : "Recargar catálogos"}
          </button>
        </div>
      </div>

      {err ? <div style={styles.error}>{err}</div> : null}

      {/* Cards */}
      <div style={styles.grid}>
        {/* Inventario */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <div>
              <div style={styles.cardTitle}>Inventario</div>
              <div style={styles.cardSub}>Equipos con filtros por estado/sede/activo.</div>
            </div>
          </div>

          <div style={styles.body}>
            <div style={styles.formGrid}>
              <div>
                <div style={styles.label}>Activo</div>
                <select
                  value={invActivo}
                  onChange={(e) => setInvActivo(e.target.value)}
                  style={styles.input}
                >
                  <option value="">(Todos)</option>
                  <option value="true">Solo activos</option>
                  <option value="false">Solo inactivos</option>
                </select>
              </div>

              <div>
                <div style={styles.label}>Sede (Ubicación)</div>
                <select
                  value={invUbicacion}
                  onChange={(e) => setInvUbicacion(e.target.value)}
                  style={styles.input}
                  disabled={loadingCats}
                >
                  <option value="">(Todas)</option>
                  {ubicaciones.map((u) => (
                    <option key={u.id_ubicacion} value={u.id_ubicacion}>
                      {u.nombre_sede}
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ gridColumn: "1 / -1" }}>
                <div style={styles.label}>Estado equipo</div>
                <select
                  value={invEstado}
                  onChange={(e) => setInvEstado(e.target.value)}
                  style={styles.input}
                  disabled={loadingCats}
                >
                  <option value="">(Todos)</option>
                  {estadosEquipo.map((es) => (
                    <option key={es.codigo_estado} value={es.codigo_estado}>
                      {es.descripcion}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div style={styles.actionsRow}>
              <button
                style={styles.smallBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/inventario.csv",
                    filename: "reporte_inventario.csv",
                    params: invParams,
                  })
                }
                disabled={downloading}
              >
                Descargar CSV
              </button>

              <button
                style={styles.primaryBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/inventario.xlsx",
                    filename: "reporte_inventario.xlsx",
                    params: invParams,
                  })
                }
                disabled={downloading}
              >
                Descargar Excel
              </button>
            </div>
          </div>
        </div>

        {/* Asignaciones */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <div>
              <div style={styles.cardTitle}>Asignaciones</div>
              <div style={styles.cardSub}>Historial de asignaciones por funcionario/equipo.</div>
            </div>
          </div>

          <div style={styles.body}>
            <label style={styles.checkRow}>
              <input
                type="checkbox"
                checked={asigSoloActivas}
                onChange={(e) => setAsigSoloActivas(e.target.checked)}
              />
              <span style={{ fontWeight: 900 }}>Solo activas (sin devolución)</span>
            </label>

            <div style={styles.actionsRow}>
              <button
                style={styles.smallBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/asignaciones.csv",
                    filename: "reporte_asignaciones.csv",
                    params: asigParams,
                  })
                }
                disabled={downloading}
              >
                Descargar CSV
              </button>

              <button
                style={styles.primaryBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/asignaciones.xlsx",
                    filename: "reporte_asignaciones.xlsx",
                    params: asigParams,
                  })
                }
                disabled={downloading}
              >
                Descargar Excel
              </button>
            </div>
          </div>
        </div>

        {/* Mantenimientos */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <div>
              <div style={styles.cardTitle}>Mantenimientos</div>
              <div style={styles.cardSub}>Listado de mantenciones con estado y fechas.</div>
            </div>
          </div>

          <div style={styles.body}>
            <div style={styles.actionsRow}>
              <button
                style={styles.smallBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/mantenimientos.csv",
                    filename: "reporte_mantenimientos.csv",
                    params: {},
                  })
                }
                disabled={downloading}
              >
                Descargar CSV
              </button>

              <button
                style={styles.primaryBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/mantenimientos.xlsx",
                    filename: "reporte_mantenimientos.xlsx",
                    params: {},
                  })
                }
                disabled={downloading}
              >
                Descargar Excel
              </button>
            </div>
          </div>
        </div>

        {/* Garantías */}
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <div>
              <div style={styles.cardTitle}>Garantías</div>
              <div style={styles.cardSub}>Por vencer (próximos X días) o vencidas.</div>
            </div>
          </div>

          <div style={styles.body}>
            <div style={styles.formGrid}>
              <div>
                <div style={styles.label}>Tipo</div>
                <select value={garTipo} onChange={(e) => setGarTipo(e.target.value)} style={styles.input}>
                  <option value="pv">Por vencer</option>
                  <option value="vencidas">Vencidas</option>
                </select>
              </div>

              <div>
                <div style={styles.label}>Días</div>
                <input
                  type="number"
                  min={1}
                  value={garDias}
                  onChange={(e) => setGarDias(Number(e.target.value || 30))}
                  style={styles.input}
                />
              </div>
            </div>

            <div style={styles.actionsRow}>
              <button
                style={styles.smallBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/garantias.csv",
                    filename: "reporte_garantias.csv",
                    params: garParams,
                  })
                }
                disabled={downloading}
              >
                Descargar CSV
              </button>

              <button
                style={styles.primaryBtn}
                onClick={() =>
                  downloadFile({
                    url: "/reportes/garantias.xlsx",
                    filename: "reporte_garantias.xlsx",
                    params: garParams,
                  })
                }
                disabled={downloading}
              >
                Descargar Excel
              </button>
            </div>
          </div>
        </div>
      </div>

      {downloading ? <div style={styles.toast}>Descargando…</div> : null}
    </div>
  );
}

const styles = {
  headerRow: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, marginBottom: 14 },
  title: { margin: 0, fontSize: 34, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 6, color: "#6b7280", fontSize: 14 },
  headerActions: { display: "flex", gap: 10, alignItems: "center" },

  grid: { display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12 },

  card: { background: "#fff", border: "1px solid #e9e9ee", borderRadius: 16, overflow: "hidden", boxShadow: "0 10px 24px rgba(0,0,0,0.04)" },
  cardHeader: { padding: "14px 16px", borderBottom: "1px solid #eef2f7", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, background: "#fafafa" },
  cardTitle: { fontSize: 14, fontWeight: 1000, color: "#0b1b3a" },
  cardSub: { marginTop: 2, fontSize: 12, color: "#6b7280" },

  body: { padding: 16 },

  formGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 },
  label: { fontSize: 12, fontWeight: 1000, color: "#667085", marginBottom: 6 },
  input: { width: "100%", height: 40, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", outline: "none", fontWeight: 800, color: "#111827" },

  actionsRow: { display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 6 },

  primaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #0b5cff", background: "#0b5cff", color: "#fff", fontWeight: 900, cursor: "pointer" },
  secondaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 800, cursor: "pointer" },
  smallBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 900, cursor: "pointer" },

  checkRow: { display: "flex", gap: 10, alignItems: "center", paddingTop: 6 },

  error: { background: "#fff2f2", border: "1px solid #ffd1d1", color: "#b42318", padding: 10, borderRadius: 12, fontSize: 13, marginBottom: 12 },

  toast: {
    position: "fixed",
    right: 16,
    bottom: 16,
    background: "#0b1b3a",
    color: "#fff",
    padding: "10px 12px",
    borderRadius: 12,
    fontWeight: 900,
    boxShadow: "0 14px 40px rgba(0,0,0,0.25)",
    zIndex: 80,
  },
};