// src/pages/LoginPage.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext.jsx";

export default function LoginPage() {
  const nav = useNavigate();
  const { login } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setErr("");
    setLoading(true);

    try {
      await login(username, password);
      nav("/dashboard", { replace: true });
    } catch (e2) {
      setErr(e2.message || "Error de login");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.shell}>
      <div style={styles.card}>
        <div style={styles.brandRow}>
          <div style={styles.logo} />
          <div>
            <div style={styles.brandTitle}>MOP Inventario TI</div>
            <div style={styles.brandSub}>Acceso al sistema</div>
          </div>
        </div>

        <form onSubmit={onSubmit} style={styles.form}>
          <label style={styles.label}>
            Usuario
            <input
              style={styles.input}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Ej: admin"
              autoComplete="username"
            />
          </label>

          <label style={styles.label}>
            Contraseña
            <input
              style={styles.input}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              type="password"
              autoComplete="current-password"
            />
          </label>

          {err ? <div style={styles.error}>{err}</div> : null}

          <button style={styles.btn} disabled={loading}>
            {loading ? "Ingresando..." : "Ingresar"}
          </button>

          <div style={styles.hint}>
            Login con <b>SimpleJWT</b> (tokens guardados por AuthContext).
          </div>
        </form>
      </div>
    </div>
  );
}

const styles = {
  shell: {
    minHeight: "100vh",
    display: "grid",
    placeItems: "center",
    background: "#f5f6f8",
    padding: 24,
  },
  card: {
    width: "100%",
    maxWidth: 420,
    background: "#fff",
    border: "1px solid #e9e9ee",
    borderRadius: 16,
    padding: 20,
    boxShadow: "0 8px 24px rgba(0,0,0,0.06)",
  },
  brandRow: {
    display: "flex",
    gap: 12,
    alignItems: "center",
    marginBottom: 14,
  },
  logo: {
    width: 36,
    height: 36,
    borderRadius: 10,
    background: "#1667ff",
  },
  brandTitle: { fontWeight: 800, color: "#0b1b3a" },
  brandSub: { fontSize: 12, color: "#667085", marginTop: 2 },
  form: { display: "flex", flexDirection: "column", gap: 12, marginTop: 10 },
  label: {
    fontSize: 12,
    color: "#344054",
    display: "flex",
    flexDirection: "column",
    gap: 6,
  },
  input: {
    height: 42,
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    padding: "0 12px",
    outline: "none",
    fontSize: 14,
  },
  btn: {
    height: 44,
    borderRadius: 12,
    border: "1px solid #0b5cff",
    background: "#0b5cff",
    color: "#fff",
    fontWeight: 700,
    cursor: "pointer",
    marginTop: 4,
  },
  error: {
    background: "#fff2f2",
    border: "1px solid #ffd1d1",
    color: "#b42318",
    padding: 10,
    borderRadius: 12,
    fontSize: 13,
  },
  hint: { fontSize: 12, color: "#667085", marginTop: 8 },
};
