import { useEffect, useMemo, useState } from "react";
import { api } from "../api/api";

export default function ConfiguracionPage() {
  // --- Sesión / usuario ---
  const [me, setMe] = useState(null);
  const [meErr, setMeErr] = useState("");

  // --- Preferencias ---
  const [darkMode, setDarkMode] = useState(
    () => localStorage.getItem("pref_dark") === "true"
  );
  const [compactTable, setCompactTable] = useState(
    () => localStorage.getItem("pref_compact_table") === "true"
  );

  // --- Sedes ---
  const [sedes, setSedes] = useState([]);
  const [sedesErr, setSedesErr] = useState("");

  // --- Test API ---
  const [pingStatus, setPingStatus] = useState("idle"); // idle | loading | ok | err
  const [pingMsg, setPingMsg] = useState("");

  const apiBaseUrl =
    import.meta?.env?.VITE_API_BASE_URL ||
    "(no definido) — revisa VITE_API_BASE_URL en .env";

  // Aplicar dark mode a <html> (simple)
  useEffect(() => {
    localStorage.setItem("pref_dark", String(darkMode));
    const root = document.documentElement;
    if (darkMode) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [darkMode]);

  useEffect(() => {
    localStorage.setItem("pref_compact_table", String(compactTable));
  }, [compactTable]);

  async function loadMe() {
    setMeErr("");
    try {
      const res = await api.get("/me/");
      setMe(res.data);
    } catch (e) {
      setMeErr(e?.response?.data?.detail || e?.message || "No se pudo cargar /me/");
    }
  }

  async function loadSedes() {
    setSedesErr("");
    try {
      const res = await api.get("/catalogos/ubicaciones/");
      const list = res.data?.results ?? res.data ?? [];
      setSedes(list);
    } catch (e) {
      setSedesErr(
        e?.response?.data?.detail || e?.message || "No se pudieron cargar sedes"
      );
    }
  }

  useEffect(() => {
    loadMe();
    loadSedes();
  }, []);

  const sedesOrdenadas = useMemo(() => {
    const arr = Array.isArray(sedes) ? [...sedes] : [];
    arr.sort((a, b) => String(a?.nombre_sede || "").localeCompare(String(b?.nombre_sede || "")));
    return arr;
  }, [sedes]);

  function logout() {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    window.location.href = "/login";
  }

  async function pingApi() {
    setPingStatus("loading");
    setPingMsg("");
    try {
      // Usamos un endpoint protegido que ya tienes funcionando
      await api.get("/dashboard/stats/");
      setPingStatus("ok");
      setPingMsg("Conexión OK ✅ (dashboard/stats respondió)");
    } catch (e) {
      setPingStatus("err");
      setPingMsg(e?.response?.data?.detail || e?.message || "Falló la conexión");
    }
  }

  return (
    <div>
      {/* Header */}
      <div style={styles.headerRow}>
        <div>
          <h1 style={styles.title}>Configuración</h1>
          <div style={styles.sub}>
            Sesión · preferencias · sedes · diagnóstico del sistema.
          </div>
        </div>

        <div style={styles.headerActions}>
          <button style={styles.secondaryBtn} onClick={() => { loadMe(); loadSedes(); }}>
            Recargar
          </button>
        </div>
      </div>

      <div style={styles.grid}>
        {/* Sesión */}
        <Card
          title="Sesión"
          subtitle="Usuario autenticado y acciones rápidas"
          right={
            <button style={styles.dangerBtn} onClick={logout} title="Cerrar sesión">
              Cerrar sesión
            </button>
          }
        >
          {meErr ? <div style={styles.error}>{meErr}</div> : null}

          <div style={styles.kvGrid}>
            <KV label="Usuario" value={me?.username || me?.email || "—"} />
            <KV label="Nombre" value={me?.first_name ? `${me.first_name} ${me?.last_name || ""}` : (me?.full_name || "—")} />
            <KV label="Email" value={me?.email || "—"} />
            <KV
              label="Permisos / grupos"
              value={
                me?.groups?.length
                  ? me.groups.join(", ")
                  : me?.is_staff
                  ? "staff"
                  : "—"
              }
            />
          </div>
        </Card>

        {/* Preferencias */}
        <Card
          title="Preferencias"
          subtitle="Se guardan en este navegador (localStorage)"
        >
          <ToggleRow
            title="Modo oscuro"
            desc="Aplica una clase 'dark' al documento"
            checked={darkMode}
            onChange={() => setDarkMode((v) => !v)}
          />
          <Divider />
          <ToggleRow
            title="Tabla compacta"
            desc="Útil para ver más filas en Inventario"
            checked={compactTable}
            onChange={() => setCompactTable((v) => !v)}
          />
          <div style={styles.miniNote}>
            Tip: si quieres que Inventario use “compacta”, después lo leemos desde{" "}
            <b>pref_compact_table</b>.
          </div>
        </Card>

        {/* Sedes */}
        <Card
          title="Sedes"
          subtitle="Ubicaciones registradas (catálogo)"
          right={
            <button style={styles.smallBtn} onClick={loadSedes}>
              Actualizar sedes
            </button>
          }
        >
          {sedesErr ? <div style={styles.error}>{sedesErr}</div> : null}

          {sedesOrdenadas.length === 0 ? (
            <div style={styles.empty}>Aún no hay sedes cargadas.</div>
          ) : (
            <div style={styles.sedeList}>
              {sedesOrdenadas.map((s) => (
                <div key={s.id_ubicacion} style={styles.sedeItem}>
                  <div style={{ fontWeight: 900, color: "#0b1b3a" }}>
                    {s.nombre_sede}
                  </div>
                  <div style={styles.sedeSub}>
                    ID: <span style={styles.mono}>{s.id_ubicacion}</span>
                    {s?.region?.nombre ? ` · Región: ${s.region.nombre}` : ""}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Sistema */}
        <Card
          title="Sistema"
          subtitle="Diagnóstico y configuración del API"
          right={
            <button
              style={{
                ...styles.primaryBtn,
                opacity: pingStatus === "loading" ? 0.7 : 1,
              }}
              onClick={pingApi}
              disabled={pingStatus === "loading"}
            >
              {pingStatus === "loading" ? "Probando…" : "Probar conexión API"}
            </button>
          }
        >
          <div style={styles.kvGrid}>
            <KV label="API base" value={apiBaseUrl} />
            <KV label="Estado" value={pingStatus === "ok" ? "OK" : pingStatus === "err" ? "Error" : "—"} />
          </div>

          {pingMsg ? (
            <div
              style={{
                ...styles.notice,
                ...(pingStatus === "ok" ? styles.noticeOk : {}),
                ...(pingStatus === "err" ? styles.noticeErr : {}),
              }}
            >
              {pingMsg}
            </div>
          ) : (
            <div style={styles.miniNote}>
              Esto sirve para confirmar que el front está pegándole al backend correcto.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

/* ---------------- UI Helpers ---------------- */

function Card({ title, subtitle, right, children }) {
  return (
    <div style={styles.card}>
      <div style={styles.cardHeader}>
        <div>
          <div style={styles.cardTitle}>{title}</div>
          <div style={styles.cardSub}>{subtitle}</div>
        </div>
        {right ? <div>{right}</div> : null}
      </div>
      <div style={{ padding: 14 }}>{children}</div>
    </div>
  );
}

function KV({ label, value }) {
  return (
    <div style={styles.kv}>
      <div style={styles.kLabel}>{label}</div>
      <div style={styles.kValue}>{value}</div>
    </div>
  );
}

function Divider() {
  return <div style={styles.divider} />;
}

function ToggleRow({ title, desc, checked, onChange }) {
  return (
    <button style={styles.toggleRow} onClick={onChange}>
      <div style={{ minWidth: 0 }}>
        <div style={styles.toggleTitle}>{title}</div>
        <div style={styles.toggleDesc}>{desc}</div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={styles.toggleState}>{checked ? "ON" : "OFF"}</span>
        <div style={{ ...styles.switch, ...(checked ? styles.switchOn : {}) }}>
          <div style={{ ...styles.knob, ...(checked ? styles.knobOn : {}) }} />
        </div>
      </div>
    </button>
  );
}

/* ---------------- Styles ---------------- */

const styles = {
  headerRow: {
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: 16,
    marginBottom: 14,
  },
  title: { margin: 0, fontSize: 34, fontWeight: 900, color: "#0b1b3a" },
  sub: { marginTop: 6, color: "#6b7280", fontSize: 14 },
  headerActions: { display: "flex", gap: 10, alignItems: "center" },

  grid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 12,
    alignItems: "start",
  },

  card: {
    background: "#fff",
    border: "1px solid #e9e9ee",
    borderRadius: 16,
    overflow: "hidden",
    boxShadow: "0 10px 24px rgba(0,0,0,0.04)",
  },
  cardHeader: {
    padding: "14px 16px",
    borderBottom: "1px solid #eef2f7",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    background: "#fafafa",
  },
  cardTitle: { fontSize: 14, fontWeight: 1000, color: "#0b1b3a" },
  cardSub: { marginTop: 2, fontSize: 12, color: "#6b7280" },

  primaryBtn: {
    height: 36,
    padding: "0 12px",
    borderRadius: 12,
    border: "1px solid #0b5cff",
    background: "#0b5cff",
    color: "#fff",
    fontWeight: 900,
    cursor: "pointer",
  },
  secondaryBtn: {
    height: 40,
    padding: "0 14px",
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    color: "#111827",
    fontWeight: 800,
    cursor: "pointer",
  },
  smallBtn: {
    height: 34,
    padding: "0 12px",
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    color: "#111827",
    fontWeight: 800,
    cursor: "pointer",
  },
  dangerBtn: {
    height: 34,
    padding: "0 12px",
    borderRadius: 12,
    border: "1px solid #fecdd3",
    background: "#fff1f2",
    color: "#9f1239",
    fontWeight: 900,
    cursor: "pointer",
  },

  kvGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 10,
  },
  kv: {
    border: "1px solid #eef2f7",
    background: "#fff",
    borderRadius: 14,
    padding: 12,
    minWidth: 0,
  },
  kLabel: { fontSize: 12, color: "#667085", fontWeight: 900 },
  kValue: { marginTop: 6, fontSize: 14, color: "#111827", fontWeight: 800 },

  divider: { height: 1, background: "#eef2f7", margin: "12px 0" },

  toggleRow: {
    width: "100%",
    border: "1px solid #eef2f7",
    background: "#fff",
    borderRadius: 14,
    padding: 12,
    cursor: "pointer",
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  toggleTitle: { fontWeight: 1000, color: "#0b1b3a" },
  toggleDesc: { marginTop: 4, fontSize: 12, color: "#6b7280" },
  toggleState: { fontSize: 12, fontWeight: 1000, color: "#667085" },

  switch: {
    width: 44,
    height: 26,
    borderRadius: 999,
    border: "1px solid #e5e7eb",
    background: "#f4f4f5",
    position: "relative",
  },
  switchOn: { background: "#0b5cff", borderColor: "#0b5cff" },
  knob: {
    width: 22,
    height: 22,
    borderRadius: 999,
    background: "#fff",
    position: "absolute",
    top: 1,
    left: 1,
    transition: "left 120ms ease",
    boxShadow: "0 4px 10px rgba(0,0,0,0.12)",
  },
  knobOn: { left: 21 },

  sedeList: { display: "grid", gap: 10 },
  sedeItem: {
    border: "1px solid #eef2f7",
    background: "#fff",
    borderRadius: 14,
    padding: 12,
  },
  sedeSub: { marginTop: 6, fontSize: 12, color: "#6b7280" },
  mono: {
    fontFamily:
      "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
    fontWeight: 900,
    color: "#0b1b3a",
  },

  miniNote: { marginTop: 10, fontSize: 12, color: "#6b7280" },

  empty: {
    padding: 12,
    border: "1px dashed #e5e7eb",
    borderRadius: 12,
    color: "#6b7280",
    fontSize: 13,
    background: "#fff",
  },

  error: {
    background: "#fff2f2",
    border: "1px solid #ffd1d1",
    color: "#b42318",
    padding: 10,
    borderRadius: 12,
    fontSize: 13,
    marginBottom: 12,
  },

  notice: {
    marginTop: 12,
    padding: 10,
    borderRadius: 12,
    fontSize: 13,
    border: "1px solid #e5e7eb",
    background: "#fff",
    color: "#111827",
    fontWeight: 800,
  },
  noticeOk: { borderColor: "#abefc6", background: "#ecfdf3", color: "#067647" },
  noticeErr: { borderColor: "#fecdd3", background: "#fff1f2", color: "#9f1239" },
};