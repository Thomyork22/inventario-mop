import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../api/api";
import EquipoDetailModal from "../components/EquipoDetailModal.jsx";
import AsignarDevolverModal from "../components/AsignarDevolverModal.jsx";
import EditarEquipoModal from "../components/EditarEquipoModal.jsx";
import NuevoEquipoModal from "../components/NuevoEquipoModal.jsx";

function useDebounced(value, delay = 350) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return v;
}

export default function InventarioPage() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [catalogos, setCatalogos] = useState({
    estados: [],
    ubicaciones: [],
    marcas: [],
    tipos: [],
  });

  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounced(search, 350);

  const [filters, setFilters] = useState({
    codigo_estado: "",
    id_ubicacion: "",
    codigo_marca: "",
    codigo_tipo: "",
    activo: "",
  });

  const [ordering, setOrdering] = useState("-id_equipo");
  const [page, setPage] = useState(1);

  const [data, setData] = useState({
    count: 0,
    next: null,
    previous: null,
    results: [],
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Modal detalle
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedEquipo, setSelectedEquipo] = useState(null);

  // Modal asignar/devolver
  const [asignarOpen, setAsignarOpen] = useState(false);

  // Modal editar
  const [editarOpen, setEditarOpen] = useState(false);

  // Modal nuevo
  const [nuevoOpen, setNuevoOpen] = useState(false);

  // =========================
  // 1) Leer id_ubicacion desde URL y sincronizarlo al filtro
  // =========================
  useEffect(() => {
    const urlUbicacion = searchParams.get("id_ubicacion") || "";
    setFilters((prev) => {
      // no re-render innecesario si es igual
      if (String(prev.id_ubicacion || "") === String(urlUbicacion)) return prev;
      return { ...prev, id_ubicacion: urlUbicacion };
    });
    setPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const queryParams = useMemo(() => {
    const params = { page, ordering };

    if (debouncedSearch.trim()) params.search = debouncedSearch.trim();
    if (filters.codigo_estado) params.codigo_estado = filters.codigo_estado;
    if (filters.id_ubicacion) params.id_ubicacion = filters.id_ubicacion;
    if (filters.codigo_marca) params.codigo_marca = filters.codigo_marca;
    if (filters.codigo_tipo) params.codigo_tipo = filters.codigo_tipo;
    if (filters.activo) params.activo = filters.activo;

    return params;
  }, [page, ordering, debouncedSearch, filters]);

  // =========================
  // Helper: setFilter (con URL si es ubicación)
  // =========================
  function setFilter(key, value) {
    setPage(1);

    // Si cambia ubicación, también cambia la URL
    if (key === "id_ubicacion") {
      setSearchParams((prev) => {
        const p = new URLSearchParams(prev);
        if (value) p.set("id_ubicacion", value);
        else p.delete("id_ubicacion");
        return p;
      });
    }

    setFilters((prev) => ({ ...prev, [key]: value }));
  }

  function clearFilters() {
    setSearch("");
    setPage(1);
    setOrdering("-id_equipo");
    setFilters({
      codigo_estado: "",
      id_ubicacion: "",
      codigo_marca: "",
      codigo_tipo: "",
      activo: "",
    });

    // Limpia la URL también
    setSearchParams((prev) => {
      const p = new URLSearchParams(prev);
      p.delete("id_ubicacion");
      return p;
    });
  }

  async function reloadEquipos() {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/equipos/", { params: queryParams });
      const payload = res.data;

      const normalized = Array.isArray(payload)
        ? { count: payload.length, next: null, previous: null, results: payload }
        : {
            count: payload.count ?? 0,
            next: payload.next ?? null,
            previous: payload.previous ?? null,
            results: payload.results ?? [],
          };

      setData(normalized);
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || "Error cargando equipos";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  async function reloadSelectedEquipo() {
    if (!selectedEquipo?.id_equipo) return;
    try {
      const res = await api.get(`/equipos/${selectedEquipo.id_equipo}/`);
      setSelectedEquipo(res.data);
    } catch {}
  }

  useEffect(() => {
    let mounted = true;

    async function loadCatalogos() {
      try {
        const [estadosRes, ubicRes, marcasRes, tiposRes] = await Promise.all([
          api.get("/catalogos/estados-equipo/"),
          api.get("/catalogos/ubicaciones/"),
          api.get("/catalogos/marcas/"),
          api.get("/catalogos/tipos-equipo/"),
        ]);

        const pick = (res) => res.data?.results ?? res.data ?? [];

        if (!mounted) return;
        setCatalogos({
          estados: pick(estadosRes),
          ubicaciones: pick(ubicRes),
          marcas: pick(marcasRes),
          tipos: pick(tiposRes),
        });
      } catch (e) {
        console.error("Error cargando catálogos", e);
      }
    }

    loadCatalogos();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    reloadEquipos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryParams]);

  const equipos = data.results;

  function openDetail(equipo) {
    setSelectedEquipo(equipo);
    setDetailOpen(true);
  }

  return (
    <div>
      {/* MODAL DETALLE */}
      <EquipoDetailModal
        open={detailOpen}
        onClose={() => setDetailOpen(false)}
        equipo={selectedEquipo}
        onAssign={() => setAsignarOpen(true)}
        onEdit={() => setEditarOpen(true)}
      />

      {/* MODAL ASIGNAR/DEVOLVER */}
      <AsignarDevolverModal
        open={asignarOpen}
        onClose={() => setAsignarOpen(false)}
        equipo={selectedEquipo}
        estadosCatalogo={catalogos.estados}
        onDone={async () => {
          await reloadEquipos();
          await reloadSelectedEquipo();
        }}
      />

      {/* MODAL EDITAR */}
      <EditarEquipoModal
        open={editarOpen}
        onClose={() => setEditarOpen(false)}
        equipo={selectedEquipo}
        catalogos={catalogos}
        onSaved={async () => {
          await reloadEquipos();
          await reloadSelectedEquipo();
        }}
      />

      {/* MODAL NUEVO */}
      <NuevoEquipoModal
        open={nuevoOpen}
        onClose={() => setNuevoOpen(false)}
        catalogos={catalogos}
        onCreated={async (createdEquipo) => {
          await reloadEquipos();
          if (createdEquipo?.id_equipo) {
            setSelectedEquipo(createdEquipo);
            setDetailOpen(true);
          }
        }}
      />

      <div style={styles.headerRow}>
        <div>
          <h1 style={styles.title}>Inventario</h1>
          <div style={styles.sub}>
            Gestiona equipos, revisa estado y filtra por ubicación, marca, tipo.
          </div>
        </div>

        <div style={styles.headerActions}>
          <button style={styles.secondaryBtn} onClick={clearFilters}>
            Limpiar filtros
          </button>
          <button
            style={styles.primaryBtn}
            onClick={() => setNuevoOpen(true)}
            title="Crear nuevo equipo"
          >
            + Nuevo equipo
          </button>
        </div>
      </div>

      <div style={styles.filtersCard}>
        <div style={styles.filtersGrid}>
          <div style={styles.field}>
            <div style={styles.label}>Buscar</div>
            <input
              style={styles.input}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Inventario, serie o modelo…"
            />
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Estado</div>
            <select
              style={styles.select}
              value={filters.codigo_estado}
              onChange={(e) => setFilter("codigo_estado", e.target.value)}
            >
              <option value="">Todos</option>
              {catalogos.estados.map((x) => (
                <option key={x.codigo_estado} value={x.codigo_estado}>
                  {x.descripcion}
                </option>
              ))}
            </select>
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Ubicación</div>
            <select
              style={styles.select}
              value={filters.id_ubicacion}
              onChange={(e) => setFilter("id_ubicacion", e.target.value)}
            >
              <option value="">Todas</option>
              {catalogos.ubicaciones.map((x) => (
                <option key={x.id_ubicacion} value={String(x.id_ubicacion)}>
                  {x.nombre_sede}
                </option>
              ))}
            </select>
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Marca</div>
            <select
              style={styles.select}
              value={filters.codigo_marca}
              onChange={(e) => setFilter("codigo_marca", e.target.value)}
            >
              <option value="">Todas</option>
              {catalogos.marcas.map((x) => (
                <option key={x.codigo_marca} value={x.codigo_marca}>
                  {x.descripcion}
                </option>
              ))}
            </select>
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Tipo</div>
            <select
              style={styles.select}
              value={filters.codigo_tipo}
              onChange={(e) => setFilter("codigo_tipo", e.target.value)}
            >
              <option value="">Todos</option>
              {catalogos.tipos.map((x) => (
                <option key={x.codigo_tipo} value={x.codigo_tipo}>
                  {x.descripcion}
                </option>
              ))}
            </select>
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Activo</div>
            <select
              style={styles.select}
              value={filters.activo}
              onChange={(e) => setFilter("activo", e.target.value)}
            >
              <option value="">Todos</option>
              <option value="true">Sí</option>
              <option value="false">No</option>
            </select>
          </div>

          <div style={styles.field}>
            <div style={styles.label}>Orden</div>
            <select
              style={styles.select}
              value={ordering}
              onChange={(e) => {
                setPage(1);
                setOrdering(e.target.value);
              }}
            >
              <option value="-id_equipo">Más nuevos</option>
              <option value="id_equipo">Más antiguos</option>
              <option value="numero_inventario">Inventario A→Z</option>
              <option value="-numero_inventario">Inventario Z→A</option>
              <option value="fecha_compra">Compra (antiguos)</option>
              <option value="-fecha_compra">Compra (recientes)</option>
            </select>
          </div>
        </div>

        <div style={styles.statusRow}>
          <div style={styles.statusLeft}>
            {loading ? (
              <span style={styles.badgeInfo}>Cargando…</span>
            ) : error ? (
              <span style={styles.badgeError}>{error}</span>
            ) : (
              <span style={styles.badgeOk}>{data.count} resultado(s)</span>
            )}
          </div>

          <div style={styles.statusRight}>
            <button
              style={styles.pagerBtn}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={!data.previous || loading}
            >
              ← Anterior
            </button>
            <span style={styles.pageChip}>Página {page}</span>
            <button
              style={styles.pagerBtn}
              onClick={() => setPage((p) => p + 1)}
              disabled={!data.next || loading}
            >
              Siguiente →
            </button>
          </div>
        </div>
      </div>

      <div style={styles.tableCard}>
        <div style={styles.tableWrap}>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Inventario</th>
                <th style={styles.th}>Serie</th>
                <th style={styles.th}>Modelo</th>
                <th style={styles.th}>Tipo</th>
                <th style={styles.th}>Marca</th>
                <th style={styles.th}>Estado</th>
                <th style={styles.th}>Ubicación</th>
                <th style={{ ...styles.th, textAlign: "right" }}>Acciones</th>
              </tr>
            </thead>

            <tbody>
              {!loading && equipos.length === 0 ? (
                <tr>
                  <td style={styles.td} colSpan={8}>
                    No hay equipos con estos filtros.
                  </td>
                </tr>
              ) : (
                equipos.map((e) => (
                  <tr key={e.id_equipo} style={styles.tr}>
                    <td style={styles.td}>
                      <div style={{ fontWeight: 700, color: "#0b1b3a" }}>
                        {e.numero_inventario}
                      </div>
                      <div style={styles.mini}>
                        {e.activo ? "Activo" : "Inactivo"}
                      </div>
                    </td>

                    <td style={styles.td}>
                      <div style={{ fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace" }}>
                        {e.numero_serie}
                      </div>
                    </td>

                    <td style={styles.td}>{e.modelo || "-"}</td>
                    <td style={styles.td}>{e.tipo_equipo?.descripcion || "-"}</td>
                    <td style={styles.td}>{e.marca?.descripcion || "-"}</td>

                    <td style={styles.td}>
                      <span style={pillStyle(e.estado?.descripcion)}>
                        {e.estado?.descripcion || "-"}
                      </span>
                    </td>

                    <td style={styles.td}>
                      {e.ubicacion?.nombre_sede || "-"}
                      <div style={styles.mini}>
                        {e.ubicacion?.region?.nombre ? `Región: ${e.ubicacion.region.nombre}` : ""}
                      </div>
                    </td>

                    <td style={{ ...styles.td, textAlign: "right" }}>
                      <button style={styles.rowBtn} onClick={() => openDetail(e)}>
                        Ver
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function pillStyle(label) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    padding: "6px 10px",
    borderRadius: 999,
    fontSize: 12,
    fontWeight: 700,
    border: "1px solid #e9e9ee",
    background: "#fff",
    color: "#111827",
  };
  const l = (label || "").toLowerCase();
  if (l.includes("ocup")) return { ...base, background: "#fff7ed", borderColor: "#fed7aa", color: "#9a3412" };
  if (l.includes("libre") || l.includes("dispon")) return { ...base, background: "#ecfdf3", borderColor: "#abefc6", color: "#067647" };
  if (l.includes("baja")) return { ...base, background: "#fff1f2", borderColor: "#fecdd3", color: "#9f1239" };
  return base;
}

const styles = {
  headerRow: { display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16, marginBottom: 14 },
  title: { margin: 0, fontSize: 34, fontWeight: 800, color: "#0b1b3a" },
  sub: { marginTop: 6, color: "#6b7280", fontSize: 14 },
  headerActions: { display: "flex", gap: 10, alignItems: "center" },
  primaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #0b5cff", background: "#0b5cff", color: "#fff", fontWeight: 800, cursor: "pointer" },
  secondaryBtn: { height: 40, padding: "0 14px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", color: "#111827", fontWeight: 700, cursor: "pointer" },
  filtersCard: { background: "#fff", border: "1px solid #e9e9ee", borderRadius: 16, padding: 14, boxShadow: "0 8px 24px rgba(0,0,0,0.04)" },
  filtersGrid: { display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr 0.8fr 1fr", gap: 10, alignItems: "end" },
  field: { display: "flex", flexDirection: "column", gap: 6, minWidth: 0 },
  label: { fontSize: 12, color: "#667085", fontWeight: 700 },
  input: { height: 40, borderRadius: 12, border: "1px solid #e5e7eb", padding: "0 12px", outline: "none", fontSize: 14, width: "100%" },
  select: { height: 40, borderRadius: 12, border: "1px solid #e5e7eb", padding: "0 10px", outline: "none", fontSize: 14, background: "#fff", width: "100%" },
  statusRow: { marginTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 },
  statusLeft: { display: "flex", alignItems: "center", gap: 8 },
  statusRight: { display: "flex", alignItems: "center", gap: 8 },
  badgeOk: { display: "inline-flex", padding: "6px 10px", borderRadius: 999, background: "#eef4ff", border: "1px solid #dbeafe", color: "#0b4edb", fontSize: 12, fontWeight: 800 },
  badgeInfo: { display: "inline-flex", padding: "6px 10px", borderRadius: 999, background: "#f4f4f5", border: "1px solid #e4e4e7", color: "#111827", fontSize: 12, fontWeight: 800 },
  badgeError: { display: "inline-flex", padding: "6px 10px", borderRadius: 999, background: "#fff1f2", border: "1px solid #fecdd3", color: "#9f1239", fontSize: 12, fontWeight: 800 },
  pagerBtn: { height: 36, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", fontWeight: 800, cursor: "pointer" },
  pageChip: { fontSize: 12, fontWeight: 800, color: "#111827", background: "#f4f4f5", border: "1px solid #e4e4e7", padding: "6px 10px", borderRadius: 999 },
  tableCard: { marginTop: 14, background: "#fff", border: "1px solid #e9e9ee", borderRadius: 16, overflow: "hidden", boxShadow: "0 8px 24px rgba(0,0,0,0.04)" },
  tableWrap: { overflowX: "auto" },
  table: { width: "100%", borderCollapse: "separate", borderSpacing: 0 },
  th: { textAlign: "left", fontSize: 12, color: "#667085", padding: "12px 14px", borderBottom: "1px solid #eef2f7", background: "#fafafa", whiteSpace: "nowrap" },
  tr: { borderBottom: "1px solid #f1f5f9" },
  td: { padding: "12px 14px", borderBottom: "1px solid #f1f5f9", verticalAlign: "top", fontSize: 14, color: "#111827" },
  mini: { fontSize: 12, color: "#6b7280", marginTop: 4 },
  rowBtn: { height: 34, padding: "0 12px", borderRadius: 12, border: "1px solid #e5e7eb", background: "#fff", fontWeight: 800, cursor: "pointer" },
};