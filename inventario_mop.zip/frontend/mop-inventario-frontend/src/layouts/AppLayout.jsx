import { Outlet } from "react-router-dom";
import Sidebar from "../components/Sidebar.jsx";
import Topbar from "../components/Topbar.jsx";

export default function AppLayout() {
  return (
    <div style={styles.shell}>
      <Sidebar />
      <div style={styles.main}>
        <Topbar />
        <div style={styles.content}>
          <Outlet />
        </div>
        <footer style={styles.footer}>
          © 2026 MOP Inventario TI. Todos los derechos reservados.
        </footer>
      </div>
    </div>
  );
}

const styles = {
  shell: {
    minHeight: "100vh",
    display: "flex",
    background: "var(--bg)", // ✅ ahora respeta dark/light
    color: "var(--text)",
  },
  main: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    minWidth: 0,
  },
  content: {
    padding: "24px",
    flex: 1,
  },
  footer: {
    borderTop: "1px solid var(--border)",
    padding: "12px 24px",
    fontSize: 12,
    color: "var(--muted)",
    background: "var(--card)", // ✅ ahora respeta dark/light
  },
};